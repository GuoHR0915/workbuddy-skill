# 下游分析（R）：分析前评估三图

拿到表达矩阵、开始差异分析前，**必须画三张图**评估样本质量与分组是否分得开：

1. PCA 图（分组差异）
2. 组间相关性热图（**两版**：全部基因 / MAD 最大的 top 2000 基因）
3. 层次聚类热图/树状图

> 若分组在三张图中体现不出来，后续差异分析有风险。此时应排查离群样本、
> 检查中间过程问题、或寻找混杂因素。

## 0. 分组与主题

```r
Group <- factor(c(rep("Normal", 3), rep("Tumor", 3)),
                levels = c("Normal", "Tumor"))

library(ggplot2)
mytheme <- theme_bw() +
  theme(legend.key = element_rect(fill = "transparent"),
        legend.background = element_rect(fill = "transparent"),
        legend.position = "top",
        legend.title = element_blank(),
        legend.text = element_text(size = 20, margin = margin(t = 6)),
        axis.text.x = element_text(hjust = 0.5, size = 18),
        axis.text.y = element_text(size = 18),
        axis.title.x = element_text(size = 20),
        axis.title.y = element_text(size = 20),
        axis.line = element_line(size = 1),
        plot.title = element_text(size = 24, hjust = 0.5))
```

## 1. PCA 分析

```r
library(FactoMineR); library(factoextra)
set.seed(1234)
PCAData <- PCA(t(log2(exp_TPM + 1)), scale.unit = TRUE, ncp = 5, graph = FALSE)

PCAPlot <- fviz_pca_ind(PCAData,
                        geom.ind = "point",          # 或 c("point","text") 显示样本名
                        pointsize = 6,
                        col.ind = Group,
                        addEllipses = TRUE,
                        mean.point = FALSE,
                        palette = c("#982b2b", "#0074b3")) +
           ggtitle("FactoMineR::PCA") + mytheme
```

- 手动提取坐标绘图：`PCAData$ind$coord`；解释方差：`PCAData$eig`。
- 也可用 base 的 `prcomp`：

```r
PCAData2 <- prcomp(t(log2(exp_TPM + 1)), scale = TRUE, center = TRUE)
summary(PCAData2)                     # 方差解释比例
fviz_screeplot(PCAData2, addlabels = TRUE, ylim = c(0, 55))
fviz_pca_ind(PCAData2, geom.ind = "point", pointsize = 6, col.ind = Group,
             addEllipses = TRUE, mean.point = FALSE,
             palette = c("#982b2b", "#0074b3")) + ggtitle("stat::prcomp") + mytheme
```

- `prcomp` 与 `PCA()` 坐标可能镜像对称，属正常（PC 方向符号不唯一）。

## 2. 组间相关性热图（两版：全部基因 + MAD top 2000）

同一套参数画两版，只有基因集不同，两版**都要出**：

```r
library(pheatmap)
expr_log <- log2(exp_TPM + 1)

## Spearman r 与 p 值：基 R 实现，不依赖 psych（p 值 t 近似，与其一致）
cor_spearman <- function(mat) {
  r <- cor(mat, method = "spearman")
  n <- ncol(mat)
  tstat <- r * sqrt((n - 2) / (1 - r^2))
  p <- 2 * pt(-abs(tstat), df = n - 2)
  p[!is.finite(p)] <- 1        # 完全相关或常数列
  diag(p) <- 0
  list(r = r, p = p)
}

## 相关性热图：两版共用同一函数，保证色板/聚类方法可比
corr_heat <- function(mat, tag) {
  cc <- cor_spearman(mat)      # 装了 psych 亦可换 psych::corr.test(mat, method = "spearman")
  pheatmap(cc$r,
           scale = "none",
           fontsize_number = 12, fontsize_row = 18, fontsize_col = 18,
           cellwidth = 50, cellheight = 50,
           cluster_rows = TRUE, cluster_cols = TRUE,
           display_numbers = signif(cc$p, 2),
           color = colorRampPalette(c("#0f86a9", "white", "#ed8b10"))(100),
           main = tag)
}

# 版本 1：全部基因
corr_heat(expr_log, "Correlation heatmap (all genes)")

# 版本 2：MAD 最大的 top 2000 基因
top2000 <- names(head(sort(apply(expr_log, 1, mad), decreasing = TRUE), 2000))
corr_heat(expr_log[top2000, ], "Correlation heatmap (top 2000 MAD genes)")
```

- **两版的用途不同，缺一不可**：
  - 全基因版：确认整体数据质量。样本间相关系数通常整体偏高（0.9 以上），
    个别样本明显偏低即提示离群或降解；
  - MAD top 2000 版：去掉低变异基因的"背景拉平"效应，用于看组内 vs 组间结构、
    是否被批次/混杂因素主导。
- **计算口径**：MAD 在 `log2(expr + 1)` 尺度上按行计算（`apply(expr_log, 1, mad)`），
  避免高表达基因主导；两版必须用同一矩阵、同一相关系数（spearman）、
  同一聚类方法（complete），否则不可横向比较。
- **命名**：`<NN>-Bioshrimp-Beta version-<数据集>-Cor-AllGenes`、
  `<NN>-Bioshrimp-Beta version-<数据集>-Cor-Top2000MAD`（命名规范见
  `references/output-conventions.md`）。
- **依赖**：不强制 `psych`；上面的 `cor_spearman()` 用基 R 实现，p 值与其
  `corr.test` 的 t 近似一致。装了 `psych` 可直接替换，结果等价。
- 若改用 vst/rlog 矩阵，两版仍按同一矩阵口径计算，并在结果说明中注明。

## 3. 样本层次聚类

```r
## 基因集：与相关性热图同口径（MAD top 2000，log2 尺度）——树与热图共用
Genelist <- names(head(sort(apply(log2(exp_TPM + 1), 1, mad), decreasing = TRUE), 2000))
exp_Cluster <- log2(exp_TPM[Genelist, ] + 1)

# 树状图
TreeData <- dist(t(exp_Cluster), method = "euclidean")
Treeresult <- hclust(TreeData, method = "complete")
library(factoextra)
fviz_dend(Treeresult, k = 2, main = "Hierarchical Clustering",
          cex = 1, horiz = TRUE, color_labels_by_k = TRUE,
          palette = rev(c("#982b2b", "#0074b3")), rect = TRUE) +
  theme_void() + theme(plot.title = element_text(size = 24, hjust = 0.5))

# 热图（与树同一 exp_Cluster）
annotation_col <- data.frame(Group = Group)
rownames(annotation_col) <- colnames(exp_Cluster)
ann_colors <- list(Group = c(Normal = "#0074b3", Tumor = "#982b2b"))
pheatmap(exp_Cluster,
         scale = "row",
         annotation_col = annotation_col, annotation_colors = ann_colors,
         fontsize_col = 12, angle_col = 0,
         cluster_rows = TRUE, cluster_cols = TRUE,
         color = colorRampPalette(c("#0f86a9", "white", "#ed8b10"))(100),
         show_rownames = FALSE)
```

- 距离度量（euclidean/manhattan）、聚类方法（complete/average/ward.D2）多种可选，
  此处仅作评估，不深究。
- 聚类热图的基因集**固定取 MAD top 2000**，与相关性热图（`-Cor-Top2000MAD`）
  同口径、同 `log2(expr + 1)` 尺度，两者结果可直接对照；
  不要另设 3000/5000 等不同阈值，避免"同一批样本两套基因集"的解读困扰。
