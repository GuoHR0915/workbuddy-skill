# 下游分析（R）：定量转换与基因 ID 转换

目标：把 count 矩阵转换为 TPM/FPKM，并把基因 ID 转为 SYMBOL，为评估与差异分析做准备。

## 1. Count → TPM / FPKM

需要每个基因的有效长度（非冗余外显子长度之和）。从 GTF 提取：

```r
library(rtracklayer)
gtf <- rtracklayer::import("<GTF 路径>/gencode.vM25.annotation.gtf.gz")
gtf <- as.data.frame(gtf)

# 提取非冗余外显子长度
exon <- gtf[gtf$type == "exon", c("start", "end", "gene_id")]
gle <- lapply(split(exon, exon$gene_id), function(x) {
  tmp <- apply(x, 1, function(y) y[1]:y[2])
  length(unique(as.integer(unlist(tmp))))
})
gle <- data.frame(gene_id = names(gle), length = as.numeric(gle))
```

转换函数：

```r
# Count → FPKM
CountToFPKM <- function(counts, effLen) {
  N <- sum(counts)
  exp(log(counts) + log(1e9) - log(effLen) - log(N))
}
exprSetFPKM <- apply(exprSet, 2, CountToFPKM, effLen = gle$length)

# Count → TPM
CountToTPM <- function(counts, effLen) {
  rate <- log(counts) - log(effLen)
  denom <- log(sum(exp(rate)))
  exp(rate - denom + log(1e6))
}
exprSetTPM <- apply(exprSet, 2, CountToTPM, effLen = gle$length)
```

- 基因有效长度也可用 GenomicFeatures 包计算（见用户笔记 `其他背景 4.定量转换.md`）。
- 若定量器（salmon/RSEM）已给出 TPM，可跳过本步。

## 2. 基因 ID 转换（ENSEMBL → SYMBOL）

从 GTF 提取对应关系（推荐，与定量口径一致）：

```r
ids <- data.frame(
  ENSEMBL = gtf$gene_id[gtf$type == "gene"],
  SYMBOL  = gtf$gene_name[gtf$type == "gene"]
)
```

对齐并去重（按 SYMBOL 排序后取平均表达最高的一条）：

```r
exprSet <- exprSet[ids$ENSEMBL, ]              # 先按 ENSEMBL 对齐
dat <- exprSet
ids$max <- apply(dat, 1, mean)                 # 每个基因的平均表达
ids <- ids[order(ids$SYMBOL, ids$max, decreasing = TRUE), ]
ids <- ids[!duplicated(ids$SYMBOL), ]          # 每个 SYMBOL 保留最高表达
dat <- dat[ids$ENSEMBL, ]
rownames(dat) <- ids$SYMBOL
exp_Count <- dat
exp_TPM  <- exprSetTPM[ids$ENSEMBL, ]; rownames(exp_TPM)  <- ids$SYMBOL
exp_FPKM <- exprSetFPKM[ids$ENSEMBL, ]; rownames(exp_FPKM) <- ids$SYMBOL
```

常用 R 包方式（在线/org.db）：

```r
library(clusterProfiler)   # bitr
bitr(Genelist, fromType = "ENSEMBL",
     toType = c("ENTREZID", "SYMBOL"), OrgDb = org.Hs.eg.db)  # 或 org.Mm.eg.db
```

- `bitr` 可能丢一部分 ID（"N% of input gene IDs are fail to map"），富集前注意。
- 同源基因转换（人↔鼠）用 `babelgene` 或 `homologene` 包（见用户笔记
  `其他背景 3.同源基因转换.md`）。

## 3. 管家基因校验（图个心安）

```r
exp_Count["Gapdh", ]       # 鼠；人用 "GAPDH"
exp_TPM["Gapdh", ]
par(mfrow = c(2, 2))
boxplot(exp_TPM, main = "TPM");  boxplot(log2(exp_TPM + 1), main = "log2 TPM")
boxplot(exp_FPKM, main = "FPKM"); boxplot(log2(exp_FPKM + 1), main = "log2 FPKM")
```

## 4. 过滤低表达基因

```r
minRow <- rowMeans(exp_Count) > 1                        # 平均表达 > 1
minNum <- rowSums(exp_Count > 0) >= 0.8 * ncol(exp_Count) # 80% 样本有表达
exp_Count <- exp_Count[minRow & minNum, ]
exp_FPKM <- exp_FPKM[rownames(exp_Count), ]
exp_TPM  <- exp_TPM[rownames(exp_Count), ]
```

- 阈值可按数据规模调整；过滤后再做评估与差异分析。
- 差异分析时 DESeq2/edgeR 内部还会做进一步过滤。
