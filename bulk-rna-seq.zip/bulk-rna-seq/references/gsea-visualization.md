# GSEA 富集分析可视化全解（GseaVis / enrichplot / fgsea / msigdbr）

本模块系统承载 GSEA 基因集富集分析的**方法、数据获取、可视化**全套知识，
内容提炼自「被炸熟的虾」公众号 GSEA 系列贴文（GSEA、GseaVis、
enrichplot、ssGSEA+GSVA 与自定义基因集）。

与 `downstream-enrich.md` 的差异：本模块聚焦 **GSEA（排序列表富集）** 的
深度可视化与基因集管理；ORA/GSVA/DO 富集仍在 `downstream-enrich.md`。

## 0. 基因集获取：msigdbr（推荐，解决 KEGG 联网失败）

`msigdbr` 包离线提供 MSigDB 全部物种/类别的基因集，**无需联网**，是
`gseKEGG`/`enrichKEGG` 联网失败时的首选降级方案（配合 `output-conventions.md`）。

```r
library(msigdbr)
# 查看支持的物种
msigdbr_species()
# 取小鼠全部基因集
Mouse <- msigdbr(species = "Mus musculus")          # 人 "Homo sapiens"
unique(Mouse$gs_subcat)   # 含 "CP:KEGG" "CP:REACTOME" "GO:BP" 等

# 提取小鼠 KEGG 通路（关键：msigdbr 里 KEGG 在 C2/CP:KEGG，而非缺失）
KEGG_df <- msigdbr(species = "Mus musculus", category = "C2",
                   subcategory = "CP:KEGG") %>%
           dplyr::select(gs_exact_source, gene_symbol)
# 转成 clusterProfiler 的 TERM2GENE 两列格式
term2gene <- KEGG_df[, c("gs_exact_source", "gene_symbol")]
```

> 注意：本地下载的 `m2.cp.*.gmt` 新版**已移除 KEGG**（版权），但 `msigdbr`
> 的 `CP:KEGG` 子类仍保留 KEGG 通路。两者口径不同，使用时以 msigdbr 为准，
> 并把基因集来源与版本写进结果说明。

## 1. GSEA 四种实现方法

排序列表构造：`geneList <- sort(setNames(res$log2FoldChange, ids$ENTREZID), decreasing=TRUE)`。

### 方法一：clusterProfiler::GSEA（自定义 TERM2GENE）

```r
library(clusterProfiler)
gmt <- read.gmt("<MSigDB 目录>/m2.cp.kegg_legacy.v2026.1.Mm.symbols.gmt")  # KEGG；或 msigdbr 的 C2:CP:KEGG
set.seed(1234)
egmt <- GSEA(geneList, TERM2GENE = gmt,
             minGSSize = 10, maxGSSize = 10000,
             pvalueCutoff = 1, pAdjustMethod = "BH",
             BPPARAM = BiocParallel::SerialParam())   # 单线程，防 fgsea 崩溃
res <- egmt@result
```

### 方法二：gseKEGG / gseGO（在线，ENTREZID）

```r
gseaKEGG <- gseKEGG(geneList, organism = "mmu", pvalueCutoff = 1,
                    BPPARAM = SerialParam())          # 联网，可能失败
gseaGO <- gseGO(geneList, OrgDb = org.Mm.eg.db, ont = "BP",
                pvalueCutoff = 1, by = "fgsea",
                BPPARAM = SerialParam())
# ENTREZID 转回 SYMBOL
gseaGO <- setReadable(gseaGO, OrgDb = "org.Mm.eg.db", keyType = "ENTREZID")
```

- gseKEGG/gseGO 只接受 ENTREZID；在线抓取，**同代码隔时运行结果会变**（尤其 GO）。
- 联网失败降级策略见 `output-conventions.md` 第 3 节（用 msigdbr/本地 gmt）。

### 方法三：fgsea::fgsea（需 list 输入）

```r
library(fgsea)
kegg.list <- split(gmt$gene, gmt$term)     # data.frame -> list
set.seed(1234)
fgseaRes <- fgsea(pathways = kegg.list, stats = geneList,
                  minSize = 10, maxSize = 10000)
sig <- fgseaRes[fgseaRes$pval < 0.05, ]
sig <- sig[order(sig$NES, decreasing = TRUE), ]
```

### 结果三线表

```r
sjPlot::tab_df(title = "", gesa_res[, c("Description","setSize","NES","pvalue","p.adjust")])
```

## 2. GseaVis 优雅可视化（推荐，逐个通路出图）

输入 clusterProfiler 的 `GSEA`/`gseGO`/`gseKEGG` 结果。安装：
`remotes::install_github("junjunlab/GseaVis")`。

> **使用边界（重要）**：`gseaNb` 的**多通路叠加**属于"按执行者要求定制"的图，
> **默认不输出**（开关 `run_multi_gsea <- FALSE`）；
> 默认交付的是**逐条通路**图（`gseaplot2` 单条，one pathway per file），
> 出图范围为**全部显著通路**（`p.adjust < 0.05`，不设 top 10 上限；显著条目多时
> 文件数相应增加属预期），且 **GO 与 KEGG** 每个做过的集合都要出
> （用户点名追加 Hallmark / Reactome 时一并覆盖），不能只挑一套集合出图。
> `gseaNb` 也可用于单条通路（`geneSetID = 单个`），这种用法不受限制。

### 2.1 基础用法与关键参数

```r
library(GseaVis)
# 单通路
p <- gseaNb(object = egmt, geneSetID = "HALLMARK_TNFA_SIGNALING_VIA_NFKB")

# subPlot 控制子图层：1=仅曲线；2=曲线+热图；3=曲线+热图+基因位置
gseaNb(object = egmt, geneSetID = x, subPlot = 2, termWidth = 30)  # termWidth 换行

# 标记通路内基因（addGene + rmSegment + arrowType + geneCol）
gseaNb(object = egmt, geneSetID = x, subPlot = 2,
       addGene = c("CCNL1","SPSB1"), geneSize = 4,
       rmSegment = TRUE, arrowType = "open", geneCol = "black")

# 添加 NES/P 值（addPval + pvalX/pvalY/pCol/pvalSize/pHjust）
gseaNb(object = egmt, geneSetID = x, addPval = TRUE,
       pvalX = 0.55, pvalY = 0.8, pCol = "black", pvalSize = 5, pHjust = 0)
```

### 2.2 更换绘图风格（newGsea）

```r
gseaNb(object = egmt, geneSetID = x, newGsea = TRUE)              # 新风格
gseaNb(object = egmt, geneSetID = x, newGsea = TRUE, addPoint = FALSE)  # 去点
gseaNb(object = egmt, geneSetID = x, newGsea = TRUE,
       addPoint = FALSE, newHtCol = c("blue","white","red"))     # 改热图色
gseaNb(object = egmt, geneSetID = x, newGsea = TRUE,
       rmSegment = TRUE, rmHt = TRUE, addGene = mygene)          # 去线段/热图
```

### 2.3 多通路叠加

```r
terms <- c("HALLMARK_TNFA_SIGNALING_VIA_NFKB","HALLMARK_OXIDATIVE_PHOSPHORYLATION",
           "HALLMARK_ANGIOGENESIS","HALLMARK_PANCREAS_BETA_CELLS")
cols <- c("#88c4e8","#db6968","#982b2b","#0074b3",
          "#e5ce81","#f47720","#459943","#bdc3d2")
# curveCol 默认仅 3 色，>3 通路必须手动提供颜色表！
gseaNb(object = egmt, geneSetID = terms, subPlot = 2, curveCol = cols[1:4],
       termWidth = 35, legend.position = c(0.8,0.8),
       addPval = TRUE, pvalX = 0.05, pvalY = 0.05)
```

### 2.4 逐通路批量出图（用户偏好：每个通路单独输出）

```r
terms <- 显著通路的 ID 或 Description
gseaList <- lapply(terms, function(x){
  gseaNb(object = egmt, geneSetID = x, addPval = TRUE,
         pvalX = 0.75, pvalY = 0.75, pCol = "black", pvalSize = 4, pHjust = 0)
})
cowplot::plot_grid(plotlist = gseaList, ncol = 2, align = "hv")
```

### 2.5 多组/多样本同通路叠加（GSEAmultiGP）

把多个实验条件的同一条 GSEA 画在一起，比较通路变化：

```r
m_gsea_list <- lapply(1:3, function(x){
  gseGO(geneList = all_glist[[x]], OrgDb = org.Hs.eg.db, ont = "BP",
        minGSSize = 100, maxGSSize = 500, pvalueCutoff = 1, verbose = FALSE)
})
GSEAmultiGP(gsea_list = m_gsea_list, geneSetID = "GO:0002757",
            exp_name = c("group1","group2","group3"),
            curve.col = ggsci::pal_d3()(3),
            addPval = TRUE, pvalX = 0.99, pvalY = 0.99,
            legend.position = "right")
```

### 2.6 子图 theme 微调（GseaVis 图是 ggplot 拼接）

```r
library(patchwork)
p2 <- p
p2[[1]] <- p2[[1]] + theme_bw() +
  theme(plot.title = element_blank(), axis.text.x = element_blank(),
        axis.text.y = element_text(size = 16), axis.ticks.x = element_blank(),
        axis.title.x = element_blank(), axis.title.y = element_text(size = 18),
        legend.text = element_text(size = 16), legend.title = element_blank(),
        legend.position = c(0.7, 0.8))
p2[[3]] <- p2[[3]] + theme_bw() +
  theme(plot.title = element_text(hjust = 0.5, size = 20),
        axis.text.x = element_text(hjust = 0.5, size = 16),
        axis.text.y = element_text(size = 16),
        axis.title.x = element_text(hjust = 0.5, size = 18),
        axis.title.y = element_text(size = 18))
p2[[1]]/plot_spacer()/p2[[2]] + plot_layout(heights = c(4, -0.15, 1.5))
```

## 3. enrichplot 全系列图（对接 clusterProfiler）

`enrichplot` 基于 ggplot2，支持 `enrichResult`/`gseaResult`/`compareClusterResult`。

| 函数 | 作用 | 适用对象 |
|------|------|---------|
| `barplot` | 条形图（Count/GeneRatio，可 split 分面） | enrichResult |
| `dotplot` | 气泡图（点大小=Count，色=p 值） | 三者 |
| `cnetplot` | 基因-条目网络图（可映射 foldChange 颜色） | 三者 |
| `emapplot` | 条目相似性网络（需先 `pairwise_termsim`） | 三者 |
| `goplot` | GO 有向无环图（去冗余） | enrichResult |
| `heatplot` | 条目-基因热图 | 三者 |

> 本表只是 `enrichplot` 的**能力说明**，不是出图规范。正式出图一律遵循
> `downstream-enrich.md` §0.2：横坐标统一 −log10(p.adjust)、条形图不放图例且
> 左侧 `expand` 为 0、GSEA 的上调与下调分开各出 top20。
| `treeplot` | 条目聚类树 | 三者 |
| `upsetplot` | UpSet 图 | 三者 |
| `gseaplot2` | GSEA 本地风格（ES 曲线+基因位置+rank） | gseaResult |
| `gsearank` | 基因排序 rank 图 | gseaResult |
| `ridgeplot` | 山脊图（核心富集基因 log2FC 分布） | gseaResult |

### gseaplot2（enrichplot 的 GSEA 主图）

```r
library(enrichplot)
gseaplot2(egmt, geneSetID = "HALLMARK_TNFA_SIGNALING_VIA_NFKB",
          title = "...", color = "red", base_size = 14,
          rel_heights = c(1, 0.2, 0.4), subplots = 1:3,
          pvalue_table = FALSE, ES_geom = "line")
# 多基因集
gseaplot2(egmt, geneSetID = rownames(res)[1:4], subplots = 1:3, ES_geom = "line")
```

### gsearank / ridgeplot

```r
gsearank(egmt, res$ID[1], title = res$Description[1])
ridgeplot(egmt, showCategory = 15, fill = "p.adjust",
          core_enrichment = TRUE, label_format = 30)
```

### 循环导出全部显著通路（标题带 P/ES/NES）

```r
results <- lapply(res$Description, function(x){
  Pvalue <- round(res[x, "pvalue"], 3)
  NES <- round(res[x, "NES"], 3)
  color <- ifelse(NES > 0, "red", "green")
  gseaplot2(egmt, color = color, geneSetID = x,
            title = paste0(x, "\nPValue = ", Pvalue, " NES = ", NES))
})
```

## 4. 自定义基因集（GMT 文件制作）

GMT 格式：第 1 列基因集名，第 2 列描述（可空），第 3 列起为基因名，
每行列数可不一致（基因数不同）。

```r
# list -> gmt
write.gmt <- function(gs, file){
  sink(file)
  lapply(names(gs), function(i){
    cat(paste(c(i, "tmp", gs[[i]]), collapse = "\t")); cat("\n")
  })
  sink()
}
write.gmt(gcSample, "my.gmt")
# 读取两种方式
gmt1 <- GSEABase::getGmt("my.gmt")          # GeneSetCollection 对象
gmt2 <- clusterProfiler::read.gmt("my.gmt") # 两列 data.frame (term, gene)
```

- 直接构造两列 `data.frame(term=..., gene=...)` 即可跳过 gmt 文件，
  如组织特异性基因集（GTEx/TiGER）等自定义集合。
- 案例：`自定义数据集.md` 的 CRC 肝转移组织特异性基因集 GSEA
  （PMID 31811277，Cell Res 2020）。

## 5. 分析实例：Wwp1 KO vs WT 小鼠（GSE126789，与 GSE94543 同构）

完整流程可参照 `GSEA.md` 第 373 行起的实战：下载 RAW → DESeq2 差异 →
`gseKEGG(organism="mmu")` → `gseaplot2` 画 PI3K-AKT（mmu04151）。要点：

```r
eg <- bitr(rownames(DEG), fromType = "ENSEMBL", toType = "ENTREZID", OrgDb = org.Mm.eg.db)
gene_list <- sort(setNames(DEG$log2FoldChange, DEG$ENTREZID), decreasing = TRUE)
kk <- gseKEGG(gene_list, organism = "mmu")
gseaplot2(kk, geneSetID = "mmu04151",
          title = paste0("KO vs WT\nKEGG PI3K/AKT Signaling Pathway\nP.adjust = ", Padjust))
```
