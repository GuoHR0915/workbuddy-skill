# 下游分析（R）：药敏预测（Drug Sensitivity Prediction）

基于细胞系药物筛选数据（GDSC/CTRP/CGP），用岭回归从肿瘤表达谱预测药物敏感性
（IC50/药物反应），内容提炼自「被炸熟的虾」公众号贴文。

## 0. 药物资源概览

| 资源 | 说明 |
|------|------|
| CTRP | 癌症治疗反应门户，细胞系药物敏感性 |
| GDSC | 肿瘤药物敏感性基因组学数据库（芯片，RMA+log） |
| CGP | Cancer Genome Project：1000+ 细胞系、200+ 药物（pRRophetic 内置） |
| CellMiner | NCI-60 细胞系，药敏相关性分析 |
| Drug Bank / CMAP / RNAactDrug / GSCALite | 药物信息与在线分析 |

## 1. CellMiner 药敏相关性分析

用 NCI-60 细胞系的药物活性与基因表达做相关性，寻找与基因相关的药物。

```r
# 读入药物数据（Activity 数据），筛选经 Clinical trial / FDA approved 的药物
# 读入表达数据（Gene.name.d × 细胞系）
# 对目标基因与各药物 IC50 做 Pearson/Spearman 相关，筛选显著相关药物
# 结果可视化：相关性散点图（geom_smooth + stat_cor）
```

## 2. pRRophetic（CGP 训练集，138 药物 × 727 细胞系）

未上 CRAN/Bioc，需手动安装：

```r
BiocManager::install(c('sva', 'car', 'genefilter', 'preprocessCore', 'ridge'))
# wget -O pRRophetic_0.5.tar.gz https://osf.io/dwzce/?action=download
install.packages("./pRRophetic_0.5.tar.gz", repos = NULL, dependencies = TRUE)
```

内置数据集：`bortezomibData`（硼替佐米病人表达+结局）、`ccleData`（CCLE 表达+
24 药物 504 细胞系）、`cgp2016ExprRma` + `drugData2016`（CGP，251 药物）。

核心函数 `pRRopheticPredict`：

```r
library(pRRophetic)
predictedPtype <- pRRopheticPredict(testMatrix = as.matrix(exprData),
                                    drug = "Bortezomib",
                                    tissueType = "all",
                                    batchCorrect = "eb",
                                    selection = 1,
                                    dataset = "cgp2014")   # 或 cgp2016
```

- `testMatrix`：待预测样本表达矩阵（基因 × 样本），非 log。
- `drug`：药物名；`dataset`：训练集 cgp2014 或 cgp2016。
- 预测全药物：`lapply(Druglist, function(x) pRRopheticPredict(...))` 后 `do.call(cbind)`，
  可加并行。

**R 4.0+ 兼容性坑（务必注意）**：R ≥ 4.0 时 `class(matrix)` 返回
`c("matrix", "array")` 而非 `"matrix"`，导致包内判断报错。需修改包内
`computephenotypefunction.R` 与 `summarizeGenesByMean.R` 中
`class(x) == "matrix"` 为 `class(x)[1] == "matrix"`。

结果验证：把预测敏感性按临床响应组（R/NR、pCR/RD）分组画箱线图 + `geom_signif`
t 检验，响应组应预测得更敏感。

## 3. oncoPredict（GDSC/CTRP 训练集，推荐）

`install.packages("oncoPredict")`，训练数据从 https://osf.io/c6tfx/ 下载（约 700M）：

- `GDSC2_Expr (RMA Normalized and Log Transformed).rds`（芯片，17419 × 805）
- `GDSC2_Res.rds`（IC50，805 × 198）
- `CTRP2_Expr (RPKM/TPM, not log transformed).rds`（转录组）

```r
library(oncoPredict)
dir <- "<训练数据目录>/oncoPredict-Training Data/"
GDSC2_Expr <- readRDS(file.path(dir, "GDSC2_Expr (RMA Normalized and Log Transformed).rds"))
GDSC2_Res  <- readRDS(file.path(dir, "GDSC2_Res.rds"))
GDSC2_Res  <- exp(GDSC2_Res)   # IC50 是 ln 值，需 e^IC50 还原（避免双重变换）

# 待预测样本：基因(SYMBOL) × 样本，需与训练集基因对齐
testExpr <- as.matrix(exprSet)   # 自己的表达矩阵

calcPhenotype(trainingExprData = GDSC2_Expr,
              trainingPtype = GDSC2_Res,
              testExprData = testExpr,
              batchCorrect = "eb",       # 或 "standardize"/"qn"/"none"
              powerTransformPhenotype = TRUE,
              removeLowVaryingGenes = 0.2,
              minNumSamples = 10,
              printOutput = TRUE,
              removeLowVaringGenesFrom = "rawData")
```

**batchCorrect 选择原则**：

- `"eb"`（ComBat）：芯片训练 → 芯片测试。
- `"standardize"`：芯片训练 → RNA-seq 测试（2017 IDWAS 用 GDSC 芯片 impute TCGA
  RNA-seq 的做法）。
- `"qn"`：分位数标准化；`"none"`：不做。

结果读取与可视化：

```r
library(data.table)
testPtype <- fread("./calcPhenotype_Output/DrugPredictions.csv", data.table = FALSE)
rownames(testPtype) <- testPtype[, 1]; testPtype <- testPtype[, -1]

# 按响应组（pCR vs RD）画箱线图 + t 检验
library(ggsignif); library(ggplot2)
ggplot(meta, aes(x = Group, y = `Paclitaxel_1080`, fill = Group)) +
  geom_boxplot(width = 0.4, position = position_dodge(0.9)) +
  geom_jitter(shape = 16, position = position_jitter(0.1)) +
  scale_fill_manual(values = c("white", "grey")) + theme_bw() +
  labs(title = "Paclitaxel", y = "Imputed Sensitivity Score") +
  geom_signif(comparisons = list(c("pCR", "RD")), test = "t.test",
              map_signif_level = TRUE, size = 0.5, textsize = 7.5)
# 存在离群点可用 gg.gap 截断坐标轴
```

- 预测分数越高代表越耐药（IC50 越高），响应组（pCR）通常预测得更敏感。
- 药物列名带编号（如 `Paclitaxel_1080`），可用 `sapply(strsplit(...),"[",1)` 去编号。

## 4. 核心区别小结

| 方法 | 训练集 | 安装 | 状态 |
|------|--------|------|------|
| pRRophetic | CGP（138/727） | 手动 tar.gz | 较老，R 4.0+ 需打补丁 |
| oncoPredict | GDSC/CTRP（更大） | CRAN | 推荐，维护中 |

两者本质上都是岭回归（Ridge Regression）+ 批次校正（ComBat/标准化）来 impute 药物
敏感性。oncoPredict 训练集更大、安装更方便，优先推荐。
