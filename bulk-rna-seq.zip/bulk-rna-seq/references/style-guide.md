# 风格参考（模仿用户既有文件，可灵活调整）

本模块记录用户提供的一系列参照文件所体现的**代码与出图风格**。
目标：后续产出脚本与结果时，**尽量贴近这些文件的风格**，让用户觉得
"这就是我自己的分析套路"。

> 定位：本模块是**风格参考**，不是硬性命令。遇到具体任务时以可读性、
> 可复现性、任务需求为准灵活调整；但默认应主动对照以下风格。

参照文件来源：
- 「被炸熟的虾」公众号「ORA & GSEA」系列贴文（富集分析可视化范式）
- 「被炸熟的虾」公众号「R语言画图」系列贴文（GSEA 深度绘图知识库）
- 既往项目的真实分析脚本（Step0.DEG.R）
- `GSE68468-GSEA.pdf`（逐个通路 GSEA 出图的目标风格）

## 1. 脚本组织风格（参照 Step0.DEG.R）

- 脚本开头固定三件套：
  ```r
  rm(list = ls())
  options(stringsAsFactors = F)
  setwd("./你的项目目录/")   # 或项目根目录
  ```
- 大段分隔用醒目的 `####` 注释块，如：
  ```r
  ##############################################################
  ##########################数据资料整理########################
  ##############################################################
  ```
- 变量命名风格：`exprSetCount` / `exprSetFPKM` / `exprSetTPM`、`pd`（表型）、
  `database`、`condition`、`coldata`、`dds`、`res`、`geneList`、`GO_GSEAresult`。
- 关键对象保存用 `.Rdata`（`save(x, file=...)` / `load(file=...)`），
  结果表用 `openxlsx::write.xlsx(...)`。
- 中途 `head()` 打印检查、`dim()` 检查维度是常见习惯。

## 2. DESeq2 差异分析风格（参照 Step0.DEG.R）

- 低表达过滤采用"平均值 + 非零比例"双条件：
  ```r
  minRow <- rowMeans(database) > 1
  minNum <- rowSums(database > 0) > (0.8*ncol(database))
  database <- database[minRow & minNum,]
  ```
- count 强制转整数矩阵再建 dds：
  ```r
  database <- as.matrix(database)
  tmp <- apply(database, 2, as.integer)
  rownames(tmp) <- rownames(database); database <- tmp
  ```
- 分组因子显式设 levels 定方向：
  ```r
  condition <- factor(pd1$Group, levels = c("LPS","LPS+LA"))
  ```
- 差异结果按 padj 排序、`na.omit` 后再提取。

## 3. GSEA 出图风格（参照 Step0.DEG.R + GSE68468-GSEA.pdf）

- **排序列表构造**：用 `DESeq2_DEG$log2FoldChange`，`names()` 挂 ENTREZID，
  `sort(..., decreasing=T)`，`geneList <- geneList[geneList != 0]`。
- **必须 `set.seed(1234)`**（`by="fgsea"` 前）。
- `gseGO` 参数习惯：`minGSSize=10, maxGSSize=10000, pvalueCutoff=0.1`。
- `gseKEGG`：`organism="mmu"`（人 `hsa`），`minGSSize=5`。
- **两种核心出图方式，目标都是"逐个通路清晰展示"**：

  (a) enrichplot `gseaplot2`（简单、单色、多通路）：
  ```r
  p1 <- gseaplot2(KEGG_GSEAresult, geneSetID = tmp, color = "red",
                  rel_heights = c(1.5, 0.5, 0.5), subplots = 1:3,
                  pvalue_table = T, ES_geom = "line")
  ```

  (b) GseaVis `gseaNb`（多通路彩色叠加，近似 GSE68468-GSEA.pdf）：
  ```r
  library(ggsci)
  Color <- pal_nejm()(8)      # 注意：curveCol 需手动传足量色板
  p <- gseaNb(object = KEGG_GSEAresult, geneSetID = tmp,
              curveCol = Color[1:7], subPlot = 3, termWidth = 35,
              legend.position = c(0.8,0.8),
              addPval = T, pHjust = 0, pvalX = 0.1, pvalY = 0.1, pvalSize = 6)
  ```

  (c) 子图 theme 微调 + patchwork 拼接（Step0.DEG.R 的精华）：
  ```r
  p2[[1]] <- p2[[1]] + theme_bw() + theme(...)   # 上子图（富集曲线）
  p2[[3]] <- p2[[3]] + theme_bw() + theme(...)   # 下子图（排序分布）
  p2[[1]]/plot_spacer()/p2[[2]] + plot_layout(heights = c(4,-0.15,1.5))
  ```
  字号习惯：轴文本 16、轴标题 18、图例文本 16、title 20（**大字号**）。

- **逐个通路单独出图**：对每条通路单独生成一份 PDF（命名
  `GSE<编号>-GSEA.pdf` 或 `GSE<编号>-GSEA_<通路>.pdf`），而非只出一张大图。
  出图范围为**全部显著通路**（`p.adjust < 0.05`），不按 top N 截断，供论文挑选。

## 4. 富集可视化风格（参照 ORA & GSEA 文件夹）

- 条形图 / 气泡图 / 棒棒糖图 / 上下调分面（`facet_wrap(~direction)`）等
  都是可参照范式。
- 点图/气泡图坐标：**x 一律 = −log10(p.adjust)**（不用 GeneRatio、不用 NES）、
  y=通路，`size=Count/setSize`；颜色映射另一维度——ORA 用 GeneRatio、
  GSEA 用 NES（红正蓝负），配色蓝→红梯度（`#0074b3`→`#982b2b`）。
- 条形图：x 同为 −log10(p.adjust)，**不放图例**，
  `scale_x_continuous(expand = expansion(mult = c(0, 0.05)))` 让 0 与 Y 轴重合。
- GSEA 的点图与条形图**按方向拆开各画一张**（上调、下调分别取本方向 top 20）。
- 通路名过长时自动换行或 `termWidth` 截断，保证不重叠。

## 5. 通用配色与主题（与既往投稿风格一致）

- 主色：蓝 `#0074b3`、红 `#982b2b` 或 `#ae202c`；`theme_bw`。
- GSEA 多通路可用 `ggsci::pal_nejm()`、`pal_lancet()` 等学术配色。
- 图内英文、字号宁大勿小、图例用实心方块。

## 6. 风格执行的取舍原则

- 以上风格**默认优先采用**，但遇到以下情况灵活调整：
  - 样本/通路过多导致图过密 → 增大画布或减少展示条目。
  - 需要与用户既有 pipeline 输出格式对齐 → 优先对齐既有格式。
  - 用户当场指定了不同风格 → 以当场要求为准。
- 核心不变的三点：**可复现（set.seed + 中间结果落盘）、大字号可读、
  逐个通路/逐条清晰展示重要结果**。
