# 输出规范与可重复性约定（Bioshrimp 规范）

本模块定义本 skill 的**输出命名、可重复性、结果说明文档**三条硬性约定。
所有下游分析脚本必须遵守。

## 1. 可重复性：设种子 + 保存中间结果

任何含随机性的步骤（GSEA 的 `fgsea` 置换、`gsva`、抽样等）**必须 `set.seed()`**，
并在脚本开头统一设置。示例：

```r
set.seed(1234)   # 每个脚本开头；含随机步骤前再次 set.seed
```

**中间结果必须落盘保存**（RDS / xlsx），确保任何一步失败后可从中断处续跑，
也便于复查。至少保存：

| 中间对象 | 保存格式 | 说明 |
|---------|---------|------|
| 合并后的表达矩阵（count/TPM/FPKM） | `.Rdata` + `.xlsx` | **务必输出**，勿只在内存中 |
| 过滤/去重后的矩阵 | `.Rdata` | 供下游复用 |
| DESeq2 `dds` 对象 / 差异结果 | `.Rdata` | 差异分析结果 |
| GSEA/ORA 结果对象 | `.Rdata` | 供后续可视化 |

> **对象格式统一用 `.Rdata`（`save()` / `load()`），不要混用 `.rds`**。
> 同一批交付里出现 `.rds` 与 `.Rdata` 两种格式会让下游脚本的读取路径难以统一；
> 统一后 `load()` 出来的变量名即脚本里的对象名，跨脚本衔接更直观。
> 表类结果仍按 `.xlsx` + `.txt` 双份。

示例（合并矩阵必须落盘）：

```r
count <- ...合并...            # 合并后的表达矩阵
save(count, file = "Produced by Bioshrimp/data/01-Bioshrimp-Beta version-expr_count_raw.Rdata")
write.xlsx(as.data.frame(count),
           "Produced by Bioshrimp/results/01-Bioshrimp-Beta version-expr_count_raw.xlsx",
           rowNames = TRUE)                                       # 同步 xlsx
```

> 反例（禁止）：只把合并矩阵留在内存变量里直接往下算而不写文件。
> 用户明确要求"合并后的表达矩阵没有输出"是一个必须修正的问题。

## 2. 结果说明文档（含环境配置）

每次完整分析完成后，**必须生成一份结果说明文档**，放在 `Produced by Bioshrimp/` 根目录，
命名加前缀，**且只写这一份**；同一份内容同时输出两种格式：

- **`.md`**：源文件，便于版本管理与二次编辑；
- **`.docx`**：交付/评审用，内容与 md 一一对应（标题、表格、列表全部保留）。

> 生成 docx 不要依赖 pandoc（本机常常没有）。可用 `python-docx` 写一个
> md→docx 转换脚本（约 200 行，支持标题/段落/列表/表格/代码块/加粗），
> 每次分析复用；转换后**核对表格行数与 md 一致**。
> 参考实现：`Produced by Bioshrimp/program/GSE94543-06.Word-report.py`。

内容至少包含：

1. **分析目的与数据**：数据来源（GSE 编号/样本数/分组/物种/平台）。
2. **分析流程**：每步方法、关键参数、阈值（如 `|log2FC|>1 & padj<0.05`）。
3. **环境配置**：
   - R 版本（`R.version.string`）、`sessionInfo()` 关键包版本
   - 关键 R 包及版本（DESeq2、clusterProfiler、org.*.eg.db、GSVA 等）
   - 参考基因组/基因集版本（如 MSigDB v2026.1）
   - 操作系统
4. **结果清单**：所有输出文件路径与说明。
5. **注意事项与变动**：若中途因网络/兼容性等原因更换了方法或数据源
   （见本文件第 3 节），**必须在结果说明中如实交代**。

获取环境信息示例：

```r
sink("Produced by Bioshrimp/results/env_info.txt")
cat("R version:", R.version.string, "\n")
print(sessionInfo())
sink()
```

## 3. 在线数据源失败的降级策略（GSEA / ORA）

GSEA、ORA（`gseKEGG`/`enrichKEGG` 等）常需联网访问 KEGG/在线数据库，
失败时按以下顺序降级，**并把这些变动写进结果说明文档**：

1. **首选**：在线接口（`gseKEGG`/`enrichKEGG`）。
2. **失败降级 A**：改用本地已下载的 MSigDB KEGG 基因集（`msigdbr` 的
   `category="C2", subcategory="CP:KEGG"`，或本地 `.gmt` 如
   `c2.cp.kegg_legacy.*.gmt`，见本地 MSigDB 目录）。
   - 注意：新版 MSigDB 的 C2 集合可能**已移除 KEGG 通路**（版权），
     此时优先用旧版 `c2.cp.kegg_legacy` 或 `msigdbr` 的 `CP:KEGG`，
     **口径仍是 KEGG**，不改变分析定义。
3. **确无 KEGG 时的例外**：只有在上述途径都取不到 KEGG 基因集时，
   才可考虑 Reactome（`REACTOME_` 前缀）**替代**——且必须**先告知用户、
   取得同意**，并在结果说明中标注"非默认集合、经用户同意后替换"。
   **不得用 Hallmark 顶替 KEGG**，也不得在用户未要求时顺手加入 Hallmark。
4. **失败降级 B**：从 MSigDB 官网（https://www.gsea-msigdb.org）重新下载
   对应物种/版本 `.gmt` 文件到本地后离线读入。
5. 全程**单线程**运行 fgsea 类方法（`BPPARAM = BiocParallel::SerialParam()`），
   避免多线程崩溃。

变动交代示例（写入结果说明）：

> 注：`gseKEGG` 因网络 SSL 错误无法访问 KEGG API，本地 MSigDB v2026.1 的
> C2 集合已不含 KEGG 通路，故改用本地 `c2.cp.kegg_legacy` 的 KEGG 基因集
> 完成富集，分析口径不变（仍为 KEGG）。

若确无 KEGG、经用户同意改用 Reactome，则写：

> 注：KEGG 基因集（在线接口与本地 legacy 版）均不可得，经确认改用 REACTOME
> 通路（本地 `m2.cp.v2026.1.Mm.entrez.gmt`，`REACTOME_` 前缀），
> 属非默认集合，结论解读时请注意集合粒度差异。

## 4. 输出文件格式：优先 .xlsx + 同步 .txt

所有结果表（差异基因表、GSEA/ORA 结果表、合并矩阵等）**优先输出 `.xlsx`**：

```r
library(openxlsx)
write.xlsx(df, "Produced by Bioshrimp/results/xxx.xlsx", rowNames = TRUE)
```

同时，为防止 Excel/Office 默认把某些基因名、日期样字符串（如 `MARCH1`、
`SEPT9`、`DEC1` 等）自动改成日期或数字，**每个结果表同步输出一份 `.txt`**
（制表符分隔，纯文本，不受 Office 自动改写影响）：

```r
write.table(df, "Produced by Bioshrimp/results/xxx.txt", sep = "\t", quote = FALSE,
            row.names = TRUE, col.names = NA)
```

> 基因名易被 Excel 改写是已知问题（`MARCH1`→`1-Mar`、`SEPT9`→`9-Sep`、
> `DEC1`→`1-Dec`、`2310009H01Rik` 等）。txt 版用于核对与程序读取，
> xlsx 版用于人工查看。两者内容必须一致（同一 df）。

## 5. 单一交付目录 `Produced by Bioshrimp/` 与唯一说明文档

**硬性约定**：一次分析的全部产物——图、表、中间对象、**本次用到的脚本**、
**本次下载或派生的数据**——必须集中放进项目根目录下**新建的
`Produced by Bioshrimp/` 文件夹**，不得散落在项目根目录的 `results/`、`program/`、`data/`。

固定目录结构（一次分析一个这样的文件夹）：

```
Produced by Bioshrimp/
├── Bioshrimp-Beta version-<数据集>-结果说明.md/.docx   # 唯一说明文档（两种格式）
├── program/                      # 本次分析全部脚本（R / py / sh）
├── results/                      # 按步骤分文件夹（硬性）
│   ├── 01-数据整理/               # 该步骤的全部图 + 表
│   ├── 02-分析前评估/
│   ├── 03-差异分析/
│   ├── 04-ORA/
│   └── 05-GSEA/
└── data/                         # 中间对象（.Rdata）与派生数据，平铺
```

> **`results/` 必须按步骤建子文件夹**：一个步骤的所有图与表只放进
> `results/<NN>-<步骤名>/`，不混放、不共用目录。读者按文件夹就能对应到
> "第几步做了什么"，找图不再靠文件名排序。
> 文件名**仍保留 `<NN>-` 前缀**，单独拷出一个文件时仍能溯源到步骤。
> `program/` 与 `data/` 保持平铺（`data/` 内的对象名同样带 `<NN>-` 前缀）。
> 注意：这是**交付目录内部**的 `program/`，与项目根目录的开发期 `program/` 不是一回事。

规则：

1. **说明文档只写一份**：不另建 `Produced by Bioshrimp.md` 之类的索引文档；
   输出清单、关键数字、结论、环境与变动**全部并入这一份**说明文档
   （章节：数据与目的 / 流程与参数 / 环境 / 结果 / 结论 / 变动与局限 / 输出清单）。
2. 文件名格式固定为 **`<NN>-Bioshrimp-Beta version-<数据集>-<内容>.<ext>`**：
   - `NN` 为**产生该文件的脚本步骤序号**（`01`、`02`、`03`、`04`、`05`…），
     放在文件名**最前面**，保证在资源管理器里按分析顺序排列；
   - 由多个脚本共用的图/表，用**产出它的那一步**编号（如 `04b` 重绘的图仍记 `04-`）；
   - 同一脚本的产物共享同一 `NN` 前缀，因此脚本里只需
     `step <- "04"; pre <- paste0(step, "-Bioshrimp-Beta version-<数据集>")`，
     所有 `paste0(pre, "-", 内容)` 自动带序号；
   - 跨脚本读取用**后缀匹配**（只给内容名），避免依赖上游步骤号，例如
     `find_out("expr_vst.Rdata")`。
3. **按步骤直接写入对应子目录**，不要先写根目录再靠脚本搬运；
   每个脚本开头声明自己的步骤目录，之后所有图/表都用它拼接路径：

   ```r
   base <- "./Produced by Bioshrimp"
   step <- "04"; ds <- "<数据集>"
   pre  <- paste0(step, "-Bioshrimp-Beta version-", ds)
   res_dir <- file.path(base, "results", paste0(step, "-ORA"))   # 每步一个子文件夹
   dir.create(res_dir, recursive = TRUE, showWarnings = FALSE)
   dir.create(file.path(base, "data"), recursive = TRUE, showWarnings = FALSE)

   out_r <- function(x) file.path(res_dir, paste0(pre, "-", x))   # 图/表
   out_d <- function(x) file.path(base, "data",  paste0(pre, "-", x))  # .Rdata
   ```

   子文件夹命名统一为 `<NN>-<步骤名>`（中文或英文皆可，同一项目内保持一致），
   步骤名建议：`01-数据整理`、`02-分析前评估`、`03-差异分析`、`04-ORA`、`05-GSEA`。

   跨脚本读取时用"按后缀在 data/ 中查找"的解析函数，避免依赖固定步骤号：

   ```r
   load_step <- function(suffix, base = "./Produced by Bioshrimp") {
     f <- list.files(file.path(base, "data"), pattern = suffix, full.names = TRUE)
     if (!length(f)) stop("未找到数据对象: ", suffix)
     e <- new.env(); load(f[1], envir = e); e
   }
   ```
4. 项目已有的 `results/`、`program/`、`data/` 不再放本次分析的产物；
   若历史产物已散落，迁移进 `Produced by Bioshrimp/` 并在说明文档中注明迁移。
5. 原始数据（用户提供的 GEO 下载、FASTQ 等）若体量大且为只读输入，
   可保留在原 `data/`，但**本次分析派生**的中间数据（基因长度表等）仍放入
   `Produced by Bioshrimp/data/`。
6. **不得移动、重命名或删除用户既有文件与目录**（硬性）：
   - 项目原有的 `data/`（原始数据）、`program/`（既有脚本）、`results/`（历史结果），
     以及外部参考库中的文件，**一律保持原位**；
   - `organize()` 只处理交付目录内**本次新产生**的文件，绝不扫描或搬运目录之外的文件；
   - 需要用到外部文件时按**只读引用**处理（`find_out()` 或绝对路径），
     并在说明文档中写明来源路径，**不要复制或移动原件**；
   - 只有本次分析新建的文件才允许进入 `Produced by Bioshrimp/`。
