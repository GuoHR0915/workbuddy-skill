# 下游分析（R）：差异表达分析（DESeq2 / edgeR / limma）

三种主流差异分析工具。DESeq2 与 edgeR 基于负二项分布，limma-voom 基于线性模型。

## 1. DESeq2（经 tximport 导入）

适用于 salmon/RSEM 等输出的定量结果；也可用 featureCounts 的 count 矩阵。

### 导入定量结果

```r
library(tximport); library(DESeq2)
# 转录本 id 与基因 id 对应关系（tx2gene）
# 方式一：从 GTF 提取
library(GenomicFeatures)
txdb <- makeTxDbFromGFF("gencode.v44.annotation.gtf.gz")   # 或 AnnotationDbi 方式
k <- keys(txdb, keytype = "TXNAME")
tx2gene <- select(txdb, keys = k, keytype = "TXNAME", columns = "GENEID")
# 方式二：从注释 R 包（hg19/hg38/mm9/mm10 有 TxDb 包，如 TxDb.Hsapiens.UCSC.hg38.knownGene）

files <- file.path(dir, "salmon", samples, "quant.sf")   # 定量结果路径列表
names(files) <- samples
txi <- tximport(files, type = "salmon", tx2gene = tx2gene)  # 或 type="rsem"/"kallisto"
# txi$abundance = TPM；txi$counts = count；txi$length = 有效长度
```

### 差异分析

```r
sampleTable <- data.frame(condition = Group)   # 分组因子
rownames(sampleTable) <- samples
dds <- DESeqDataSetFromTximport(txi, colData = sampleTable, design = ~condition)
dds <- DESeq(dds)
res <- results(dds, contrast = c("condition", "Tumor", "Normal"))  # 分子 vs 分母
res <- as.data.frame(res)
write.csv(res, "DEG_DESeq2.csv")
```

- `results()` 的 contrast 顺序：`c("condition", "处理组", "对照组")`，log2FC 以处理组相对对照。
- 提取 counts：`counts(dds, normalized = TRUE)`。

## 2. edgeR（DGEList）

```r
library(edgeR)
# 由 tximport 的 count 与 length 构建
cts <- txi$counts
normMat <- txi$length
normMat <- normMat / exp(rowMeans(log(normMat)))     # 长度缩放因子
o <- log(calcNormFactors(cts / normMat)) + log(colSums(cts / normMat))  # offset

y <- DGEList(cts, group = Group)
y <- calcNormFactors(y)                               # TMM 归一化
design <- model.matrix(~ 0 + Group)                   # 或 ~Group
y <- estimateDisp(y, design)
fit <- glmQLFit(y, design)                            # 或 glmFit + glmLRT
qlf <- glmQLFTest(fit)
res <- topTags(qlf, n = Inf)$table
write.csv(res, "DEG_edgeR.csv")
```

## 3. limma-voom

```r
library(limma); library(edgeR)
y <- DGEList(counts = cts, group = Group)
keep <- filterByExpr(y)            # 自动过滤低表达
y <- y[keep, , keep.lib.sizes = FALSE]
y <- calcNormFactors(y)
design <- model.matrix(~ Group)
v <- voom(y, design)
fit <- lmFit(v, design)
fit <- eBayes(fit)
res <- topTable(fit, coef = 2, number = Inf)   # coef 对应设计矩阵中的组别列
write.csv(res, "DEG_limma.csv")
```

## 4. 结果判读与导出

- 常用阈值：`|log2FC| > 1` 且 `padj < 0.05`（差异分析）；下游富集可放宽到
  `pvalue < 0.05` 或按 log2FC 排序取 top N。
- 结果列：`baseMean`、`log2FoldChange`、`lfcSE`、`stat`、`pvalue`、`padj`（DESeq2）；
  `logFC`、`AveExpr`、`t`、`P.Value`、`adj.P.Val`（limma）；`logFC`、`logCPM`、
  `F`、`PValue`、`FDR`（edgeR）。
- 导出为 CSV，供后续富集分析（`downstream-enrich.md`）读取。

## 5. 差异结果可视化

差异结果可用火山图、MA 图（`DESeq2::plotMA`、`EnhancedVolcano` 包）展示，
富集可视化见 `downstream-enrich.md`。
