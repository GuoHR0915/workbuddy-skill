# 项目脚手架与脚本命名规范

从零搭建可复现的 bulk RNA-seq 分析项目时，按以下结构组织。

## 目录结构

```
<项目名>/
├── data/            # 原始数据：fastq/gtf/count 矩阵/Rdata（只读输入）
├── program/         # 开发期脚本（可留在项目内，但定稿脚本需复制进交付目录）
│   ├── upstream/    # 上游 shell 脚本（下载/质控/比对/定量）
│   └── downstream/  # 下游 R 脚本
└── Produced by Bioshrimp/   # 单一交付目录：一次分析的全部产物
    ├── Bioshrimp-Beta version-<数据集>-结果说明.md/.docx  # 唯一说明文档（两种格式）
    ├── program/     # 本次分析定稿脚本（R / py / sh）
    ├── results/     # 按步骤分子文件夹，每步的图 + 表放在一起
    │   ├── 01-数据整理/
    │   ├── 02-分析前评估/
    │   ├── 03-差异分析/
    │   ├── 04-ORA/
    │   └── 05-GSEA/
    └── data/        # 中间对象(.Rdata) + 本次下载/派生的数据（基因长度表等）
```

> 交付时只看 `Produced by Bioshrimp/` 这一个文件夹，内部按**用途**分三层：
> 代码 `program/`、结果 `results/`、数据 `data/`。
> **`results/` 必须按步骤建子文件夹**（`<NN>-<步骤名>`），一个步骤的图与表只进自己的
> 目录，不混放；文件名仍带 `<NN>-` 前缀，单独拷出时仍可溯源到步骤。
> 项目根目录的 `results/` 不再作为本次分析的输出目录；
> 脚本直接写入对应步骤目录（`out_r()` 拼接），不靠事后搬运。

## 脚本命名规范

- 上游 shell：`StepN.<描述>.sh`（如 `Step1.download.sh`、`Step3.align.sh`）。
- 下游 R：`StepN.M.<描述>.R`（如 `Step3.1.DESeq2.R`、`Step4.2.GSEA.R`）。
- 编号与流程阶段一一对应，方便按顺序重跑。

## 可复用 R 函数（建议沉淀到 scripts/）

- `CountToTPM(counts, effLen)` / `CountToFPKM(counts, effLen)` — 定量转换。
- `gtf_gene_length(gtf_path)` — 从 GTF 提取非冗余外显子长度。
- `ensembl_to_symbol(expr, gtf_path)` — ID 转换 + 去重（取平均表达最高）。
- `mytheme` — 投稿风格 ggplot2 主题（`#0074b3`/`#982b2b`，theme_bw，大字号）。
- `draw_pca / draw_corr_heatmap_pair / draw_corr_heatmap / draw_hclust` — 评估三图；
  相关性热图用 `draw_corr_heatmap_pair()` 一次出**全部基因**与 **MAD top 2000** 两版；
  层次聚类 `draw_hclust()` 默认 `top_n = 2000L`，与 MAD 版同口径。
- `run_deseq2 / run_edgeR / run_limma` — 差异分析封装。
- `ora_plot / gsea_plot` — 富集可视化封装。

这些函数逻辑见各 `references/*.md` 中的代码片段；如需脚本化，
把对应片段整理为 `scripts/*.R` 并用 `source()` 调用。

## 复现要点

- 记录参考基因组版本、GTF 版本、工具版本（`--version`），写入 README。
- 保留中间文件（sam/bam/count）以便排查。
- 随机数 `set.seed()` 固定，保证可复现。
