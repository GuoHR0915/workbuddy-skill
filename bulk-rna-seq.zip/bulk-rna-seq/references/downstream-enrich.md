# 下游分析（R）：功能富集分析（ORA / GSEA / GSVA / ssGSEA / DO）

差异分析后，对差异基因做功能富集，解释生物学意义。

## 0. 默认范围（先看这一节，避免过度分析）

**默认基因集：只用 GO 与 KEGG。** ORA、GSEA、GSVA、ssGSEA 四类方法使用同一口径，
不因方法不同而换集合。

| 分析 | 默认 | 基因集 | 备注 |
|---|---|---|---|
| ORA — GO BP/CC/MF | ✅ 运行，**Up / Down 各一次** | GO | `enrichGO` |
| ORA — KEGG | ✅ 运行，**Up / Down 各一次** | KEGG | `enrichKEGG`；联网失败改用 `C2:CP:KEGG`（仍是 KEGG） |
| GSEA — GO / KEGG | ✅ 运行 | GO + KEGG | `gseGO` / `gseKEGG` |
| GSVA / ssGSEA | ❌ 选做 | GO + KEGG | 仅用户明确要求时运行；脚本留 `run_gsva <- FALSE` 开关 |
| 疾病注释（DO/NCG/DGN） | ❌ 选做 | — | 用户要求时再跑 |

**ORA 的方向口径（硬性）**：只做 **Up（上调 DEG）** 与 **Down（下调 DEG）** 两个基因集，
各做一次独立的 ORA；**不做 Up+Down 合并后的"全部 DEG"ORA**。
两侧方向相反，合并后同一条通路的信号会相互抵消，也无法回答"是哪一侧驱动了该通路"。
若需把两侧放在一起看，只能**将两次独立富集的结果并排展示**，
不得把基因合并成一个列表重新检验。

**默认不使用的基因集（不属于"选做项"）：**

- Hallmark（H / `mh.all`）、Reactome（`C2:CP:REACTOME`）、
  其他 MSigDB 集合（C2 / C5 / C6 / C7 …）**默认一律不用**：
  不主动跑、不主动推荐、不在开工确认中列为可选项。
- 仅当用户明确点名（"加 Hallmark"、"用 Reactome"）时才启用，
  并在结果说明中注明"按要求追加的集合"，同时说明其与 GO/KEGG 不可直接横向比较。

**执行约定：**

- 开工前用一句话确认范围即可（"默认做 GO + KEGG 的 ORA 与 GSEA，需要加
  GSVA / ssGSEA 吗？"）；用户未明确要求即按默认执行；确认里不列 Hallmark / Reactome。
- 结果说明文档写明"富集分析使用 GO 与 KEGG 基因集"；未运行的选做方法记
  "未运行（选做项）"，Hallmark / Reactome 记"未使用（默认不含该集合）"。
- 下文各节的代码是**能力清单，不是默认执行清单**；按上表按需启用。

### 0.2 出图默认规则（避免"结果看起来不一致"）

1. **点图（dotplot）：横坐标一律为 −log10(p.adjust)**，不再用 GeneRatio、也不再
   用 NES 作横坐标。
   - 取 p.adjust 最小的 20 条，**不按显著性过滤**：显著不足 20 条时也要取满 20 条，
     未达显著的标为 `Non-Sig`（空心点），不要出现"只画了 3 条显著通路"的图。
     **GSEA 例外**：先按 NES 正负拆成上调 / 下调，再在各自方向内部取 top20
     （见第 2 条），不再跨方向混排、也不标 Non-Sig。
   - y = 通路（按 p.adjust 排序），点大小 = Count（GSEA 为 setSize）；
     颜色映射另一个维度：**ORA 可用 GeneRatio**、**GSEA 必须用 NES**
     （红正 / 蓝负），否则 GSEA 的方向信息会完全丢失。
   - **ORA 的 GO BP / CC / MF / KEGG 四套，上、下调各出一张点图（共 8 张）**，
     不能只出 GO BP，也不能把 Up 与 Down 合并成一张。
2. **同一批条目还要再配一份条形图（barplot）**，与点图成对，横坐标同为
   **−log10(p.adjust)**：
   - **ORA**（GO BP/CC/MF + KEGG）：x = −log10(p.adjust)，y = 通路，按 p 排序，
     在 `p.adjust = 0.05` 处画虚线（x 位置 = 1.301）；**Up 与 Down 各画一张**
     （各自基于独立富集结果）；
   - **GSEA**（GO BP / KEGG）：**上调与下调拆成两张图**，各自取该方向最显著的
     20 条（先按 NES>0 / NES<0 拆分，再在方向内部按 p.adjust 取前 20），
     x = −log10(p.adjust)；某方向显著条目不足 20 条则全部画出，
     为 0 时不出该图并在结果说明中注明；
   - **条形图统一不放图例**：方向已在标题与配色中体现，`fill` 用单色——
     上调 `#ae202c`、下调 `#0074b3`、Non-Sig `grey75`；
   - **x 轴左侧扩展固定为 0**，使 0 与 Y 轴重合：
     `scale_x_continuous(expand = expansion(mult = c(0, 0.05)))`。
   点图看显著性 + 基因集大小，条形图看显著性量级；两者横坐标同口径，可直接对照。

   最小实现（点图与条形图共用同一份 top20 数据框 `d`，`nlp = -log10(p.adjust)`）：

   ```r
   ## 条形图：不放图例 + 左侧 expand 为 0
   ggplot(d, aes(nlp, Description)) +
     geom_col(fill = "#ae202c", width = 0.7) +          # 下调换 #0074b3
     geom_vline(xintercept = -log10(0.05), linetype = "dashed", linewidth = 0.6) +
     scale_x_continuous(expand = expansion(mult = c(0, 0.05))) +
     theme_bw() + theme(legend.position = "none")

   ## 点图：x 用 nlp，size 用 Count/setSize，颜色映射 GeneRatio(ORA) 或 NES(GSEA)
   ggplot(d, aes(nlp, Description)) +
     geom_point(aes(size = Count, colour = NES)) +
     scale_x_continuous(expand = expansion(mult = c(0, 0.05))) +
     theme_bw()
   ```

   > 注意：`enrichplot::dotplot()` 的 `x` 参数只接受原始 p.adjust / GeneRatio，
   > 不能直接输出 −log10，故一律用 ggplot2 自绘，不要用默认 `dotplot()` 交差。
3. **逐条通路图输出"全部显著通路"**（`p.adjust < 0.05`，不设 top N 上限）：
   GO BP、KEGG 各自把显著条目**全部**用 `gseaplot2(geneSetID = ...)` 单条输出，
   文件名带集合前缀（如 `-GSEA-GOBP_GO_0007059_*`、`-GSEA-KEGG_*`）。
   显著条目多（如 GO BP 上百条）时文件数会随之增加，这是预期行为，
   不得为了"图少一点"而只取前 10 条；显著通路为 0 时不出逐条图并在说明中注明。
   用户点名追加 Hallmark / Reactome 时，其通路图同样逐条输出。
4. **多通路叠加图（GseaVis `gseaNb`）不默认输出**：它属于"按执行者要求定制"的图，
   默认关闭（`run_multi_gsea <- FALSE`），用户点名要哪几条通路再开。
5. **跨集合结果不可直接横向比较**（仅在用户点名追加 Hallmark / Reactome 后才会出现），
   出图与解读时须注意：
   - 集合规模与冗余度差异极大（GO BP 数千条含大量父子术语；Hallmark 仅 50 条
     去冗余的粗通路；Reactome 约 900 条中等粒度），同一生物学过程在不同集合里
     表现为不同的 NES 与 p 值；
   - BH 校正在各自集合内部进行，跨集合的 p 值不属于同一检验族；
   - ORA 基于差异基因列表、GSEA 基于全基因排序，两者本就不等价。
   因此"GO 说细胞周期、Hallmark 说 E2F/G2M"不是矛盾，而是粒度不同的同一信号；
   报告中应写明各自的集合来源与条数，并优先比较**方向与主题**，而非 NES 绝对值。


## 0.1 准备 ENTREZID

clusterProfiler 富集需要 ENTREZID。差异基因的 SYMBOL/ENSEMBL 需先转：

```r
library(clusterProfiler)
library(org.Mm.eg.db)   # 鼠；人用 org.Hs.eg.db
ids <- bitr(genelist, fromType = "SYMBOL",
            toType = "ENTREZID", OrgDb = org.Mm.eg.db)
```

## 1. ORA 富集（GO / KEGG）

### 1.1 背景基因集（universe）必须显式指定

ORA 的 p 值完全取决于背景基因集。clusterProfiler **默认用 OrgDb / KEGG 的全注释基因**
作背景；而本实验实际只检出 1.5–2 万个基因，用默认背景等于把"根本没检出"的基因
计入分母，会**系统性高估富集显著性**（免疫细胞、分选细胞、深度不足的样本尤其明显）。

规则：`universe` 用**通过低表达过滤的全部基因**（即差异分析输入矩阵的行名），
与 DEG 列表同源、同 ID 类型。

```r
## universe：实验检出基因（不是 DEG，也不是全注释）
sym2ez_all <- bitr(rownames(exprSetCount_filter), "SYMBOL", "ENTREZID", org.Mm.eg.db)
universe_ez <- unique(na.omit(sym2ez_all$ENTREZID))       # 例：16442 个基因 → 约 1.5 万 ENTREZ

ego <- enrichGO(gene = ids$ENTREZID, OrgDb = org.Mm.eg.db,
                ont = "BP", keyType = "ENTREZID",
                universe = universe_ez,                    # ← 关键
                pAdjustMethod = "BH", pvalueCutoff = 0.05, qvalueCutoff = 0.2)
ekegg <- enrichKEGG(gene = ids$ENTREZID, organism = "mmu",  # 人 "hsa"
                    universe = universe_ez,                # ← 关键
                    pvalueCutoff = 0.05)

## 自定义 GMT / 离线 KEGG 集合：universe 必须与 TERM2GENE 的 ID 类型一致
e <- enricher(deg_symbols, TERM2GENE = cp,
              universe = rownames(exprSetCount_filter),    # GMT 是 symbol 版就用 symbol
              pvalueCutoff = 0.05)
```

- 结果表中的 `BgRatio` 应为"集合基因数 / 实验背景基因数"，据此核对 background 是否生效。
- 报告中须写明背景基因数（如"背景 = 16442 个检出基因，映射到 14903 个 ENTREZ"）。

### 1.2 基本调用（Up / Down 分开）

```r
## 只做两个基因集：上调 DEG、下调 DEG；不合并
deg_up <- unique(na.omit(anno$ENTREZID[res$change == "Up"]))
deg_dn <- unique(na.omit(anno$ENTREZID[res$change == "Down"]))

run_go <- function(genes, ont) {
  enrichGO(gene = genes, OrgDb = org.Hs.eg.db, keyType = "ENTREZID", ont = ont,
           universe = universe_ez, pAdjustMethod = "BH",
           pvalueCutoff = 1, qvalueCutoff = 1)      # 全量导出，作图时再按 p.adjust 筛
}
ego_up_BP <- run_go(deg_up, "BP");  ego_dn_BP <- run_go(deg_dn, "BP")
## CC / MF / KEGG 同理各做两次
```

> **不要**再把 `c(deg_up, deg_dn)` 合成一个列表做第三次 ORA。

> **坑：`qvalueCutoff` 默认 0.2**。`enrichKEGG` / `enricher` 若只改 `pvalueCutoff`
> 而不动 `qvalueCutoff`，结果会被悄悄截断到很少几行（常只剩 3–7 条），
> 看起来像"没有富集"。**导出全量结果表时务必 `qvalueCutoff = 1`**，
> 再在作图/筛选时按 p.adjust 控制；否则点图会只剩几个点。

### ORA 结果可视化

四种常用图（详见用户笔记 `下游分析 3.功能富集分析 ORA 结果可视化.md`）：

1. **条形图**：`barplot(ego)` 或 ggplot2 按 `-log10(p.adjust)` 排序绘制；
   可叠加散点（gene count 映射到点大小）。
2. **气泡图**：x 轴 **−log10(p.adjust)**（**不用 GeneRatio**），y 轴 pathway，
   点大小 Count，颜色可映射 GeneRatio。`enrichplot::dotplot()` 不能直接出负对数，
   按 §0.2 的最小实现用 ggplot2 自绘。
3. **棒棒糖图**：`geom_segment` + `geom_point`，展示 top pathways 的基因数/富集得分。
4. **Term/Pathway 分面**：把上/下调差异基因分别富集，`facet_wrap` 分面展示
   （用 `gtable`/`grid` 调整 strip 样式）。

- **上/下调分别富集、分别出图**：Up 一套、Down 一套，结果表分别命名
  `ORA-Up-*` / `ORA-Down-*`，点图与条形图各出两套。
- 若要把两侧放在同一张图里对照，只能**并排展示两次独立富集的结果**
  （如 Up 与 Down 各取 top N 做分面条形图），不得合并基因列表重算。
- 配色沿用 `#0074b3`（蓝，下调）/ `#982b2b`（红，上调）。

## 2. GSEA（clusterProfiler）

适用于全基因排序列表（不必先筛差异基因）。

```r
set.seed(1234)   # 必须设种子
library(BiocParallel)
# 由差异结果构造排序列表（按 log2FoldChange 降序）
geneList <- sort(setNames(res$log2FoldChange, ids$ENTREZID), decreasing = TRUE)
# 关键：加 BPPARAM = SerialParam() 强制单线程，避免 fgsea 多线程崩溃
gseaGO <- gseGO(geneList = geneList, OrgDb = org.Mm.eg.db, ont = "BP",
                pvalueCutoff = 0.05, keyType = "ENTREZID",
                BPPARAM = SerialParam())
# KEGG 在线接口（失败时按降级策略处理，见下）
gseaKEGG <- gseKEGG(geneList = geneList, organism = "mmu", pvalueCutoff = 0.05,
                    BPPARAM = SerialParam())
```

可视化：`ridgeplot`、`gseaplot`、`gseaplot2`、`dotplot`、`enrichmap`、`cnetplot`。

- 通用接口：`GSEA()` / `enricher()` 支持自定义基因集（TERM2GENE 两列 data.frame）。

### 2.1 GSEA 逐个通路出图（gseaplot2 单条；GseaVis 多通路按需）

GSEA 结果**逐个通路单独输出**（一条通路一个文件，含富集得分曲线 + p 值标注），
并且**对每个做过的集合都出全部显著通路**：GO BP、KEGG 各自把 `p.adjust < 0.05`
的条目**全部**用 `gseaplot2(geneSetID = 单条)` 输出，**不设 top 10 上限**
（用户追加 Hallmark / Reactome 时一并纳入）；文件名带集合前缀便于区分。
显著条目很多时文件数会明显增加（GO BP 上百条属正常），这是预期行为，不要截断；
若某集合无显著条目，则不出逐条图并在说明中注明。
`gseaNb()` 的多通路叠加（近似 `GSE68468-GSEA.pdf`）属定制图，默认不输出，
用户点名要哪几条通路再开。
关键包：`GseaVis`（github junjunlab/GseaVis）+ `ggsci`/`cols4all` 配色。

```r
library(GseaVis)
library(ggsci)
library(ggplot2)
Color <- pal_nejm()(8)     # 或 cols4all 的 div 色板

# 方式一：多通路叠加（近似 GSE68468-GSEA.pdf 的组合图）
p <- gseaNb(object = gseaRes,          # clusterProfiler 的 gseaResult 对象
            geneSetID = top_terms,     # 要展示的通路 ID 向量
            curveCol = Color[1:length(top_terms)],
            subPlot = 3,               # 子图（曲线 + 基因标签 + 热图）
            termWidth = 35,
            legend.position = c(0.8, 0.8),
            addPval = TRUE, pHjust = 0,
            pvalX = 0.1, pvalY = 0.1, pvalSize = 6)

# 方式二：逐个通路单独出图（每个通路一个文件）
## sig_terms = 该集合全部显著通路的 ID（p.adjust < 0.05），不是 top 10
sig_terms <- gseaRes@result$ID[gseaRes@result$p.adjust < 0.05]
for(term in sig_terms){
  p <- gseaNb(object = gseaRes, geneSetID = term,
              curveCol = "#982b2b", subPlot = 3,
              addPval = TRUE, termWidth = 35)
  # 主题微调（theme_bw，字号放大）
  pdf(paste0("GSEA_", gsub("[:/ ]", "_", term), ".pdf"), width = 8, height = 5)
  print(p)
  dev.off()
}
```

- 通路 ID 用 `gseaRes@result$ID`（或 `rownames`），描述用 `Description` 列。
- **出图范围 = 全部显著通路**（`p.adjust < 0.05`），不按 top N 截断；
  显著条目多时文件数会相应增加，属预期。
- `setReadable()` 先把 ENTREZID 转回 SYMBOL，便于基因标签可读：
  `gseaRes <- setReadable(gseaRes, OrgDb = "org.Mm.eg.db", keyType = "ENTREZID")`。
- 逐通路出图时，文件名里的通路名做安全化处理（替换 `/`、空格等）。
- 同时保留一份汇总气泡图/山脊图（`dotplot`/`ridgeplot`）作为总览。

### 2.2 在线数据源失败的降级（重要）

`gseKEGG`/`enrichKEGG` 需联网访问 KEGG API，SSL/网络失败时的降级顺序，
以及"本地 MSigDB C2 已移除 KEGG 通路"的替代方案，**见
`references/output-conventions.md` 第 3 节**。核心：

1. 在线失败 → 用本地 MSigDB `.gmt` / `msigdbr` 的 `C2:CP:KEGG`（仍是 KEGG，口径不变）。
2. 本地 C2 已无 KEGG → 先试旧版 `c2.cp.kegg_legacy`；确实取不到 KEGG 基因集时，
   **先告知用户并征得同意**，才可改用 Reactome（`REACTOME_` 前缀），
   并在结果说明中标注"非默认集合、经用户同意后替换"。
3. 所有变动写进结果说明文档。

> 补充：`msigdbr` 包的 `category="C2", subcategory="CP:KEGG"` 仍保留 KEGG 通路，
> 是联网失败后恢复 KEGG 富集的首选（详见 `gsea-visualization.md` 第 0 节）。

### 2.3 深度可视化（GseaVis / enrichplot / fgsea / 自定义 GMT）

GSEA 的**逐通路出图、GseaVis 全系列、enrichplot 全系列、fgsea 方法、
msigdbr 基因集获取、自定义 GMT 制作**等完整知识，**见
`references/gsea-visualization.md`**（内容提炼自「被炸熟的虾」公众号 GSEA 系列贴文）。做 GSEA 深度绘图时优先加载该模块。

## 3. GSVA / ssGSEA（单样本富集）

不依赖分组，对每个样本计算通路/基因集富集得分。

```r
library(GSVA); library(GSEABase)
# 基因集口径：默认用 GO 或 KEGG，与 ORA/GSEA 保持一致（不用 Hallmark / Reactome）
gs <- getGmt("c2.cp.kegg_legacy.v2026.1.Hs.symbols.gmt")   # KEGG 通路
# 或用 msigdbr 的 C2/CP:KEGG、GO:BP 子集构造成 list
# 表达矩阵（基因 × 样本，用 SYMBOL 行名）
gsva_es <- gsva(as.matrix(exp_TPM), gs, method = "gsva")     # 或 method="ssgsea"
```

- **基因集口径（硬性）**：GSVA / ssGSEA 默认取 GO 或 KEGG 基因集，不得默认换成
  Hallmark（`h.all`）、Reactome 或其他 MSigDB 集合做打分；
  免疫细胞 marker 集属于"免疫注释"范畴，按扩展分析规则单独开关。

- `method` 可选：`"gsva"`、`"ssgsea"`、`"zscore"`、`"plage"`。
- 结果矩阵（基因集 × 样本）可用 `pheatmap` 可视化、limma 做组间差异：

```r
design <- model.matrix(~ Group)
fit <- lmFit(gsva_es, design); fit <- eBayes(fit)
topTable(fit, coef = 2)
```

- 免疫浸润评估：用免疫细胞 marker 基因集跑 ssGSEA，得到各免疫细胞富集得分，
  热图展示（pheatmap 行名默认在右侧，如需左侧可用 modified_pheatmap 脚本）。

## 4. 疾病注释富集（DO / NCG / DGN）

```r
library(DOSE)
edo <- enrichDO(gene = ids$ENTREZID, ont = "DO", pvalueCutoff = 0.05)   # 疾病本体
encg <- enrichNCG(gene = ids$ENTREZID)    # Network of Cancer Genes
edgn <- enrichDGN(gene = ids$ENTREZID)    # DisGeNET
# 可视化：barplot / dotplot / cnetplot / heatplot / emapplot
```

## 5. 基因集活性评分（综述）

单样本基因集打分方法（详见用户笔记 `下游分析 6.基因集活性评分.md`）：

1. **单样本 GSEA 类**：ssGSEA、GSVA、PLAGE、z-score。
2. **降维/主成分类**：对基因集表达矩阵做 PCA，取第一主成分作为活性得分。
3. **统计/机器学习打分**：如 AUCell、AddModuleScore（Seurat）、GSVA 变体。
4. **人工定义公式**：如基因均值、比值、加权和（用户自定义 marker 公式）。

## 6. 可视化通用规范

- 图内英文，`theme_bw`，配色 `#0074b3`/`#982b2b`。
- 图例用实心方块；字号宁大勿小；不显著统一 "Non-Sig"。
- 富集结果需可查：图上标 **p.adjust（横坐标）与 Count（点大小/条长）**，
  GeneRatio 进结果表与图注；GSEA 的 NES 必须可见（点图用颜色映射）。
- 点图与条形图的横坐标统一为 **−log10(p.adjust)**；条形图不放图例，
  x 轴左侧 `expand` 为 0（0 与 Y 轴重合）。
