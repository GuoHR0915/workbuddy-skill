# 上游分析（Linux）：下载 → 质控 → 比对 → 定量

目标：从原始 FASTQ（或 .sra）得到**基因/转录本 count 矩阵**，供下游 R 分析。

## 1. 工具安装（conda 方式，推荐）

```bash
conda create -n RNA-seq
conda activate RNA-seq
conda install -c bioconda fastqc fastp hisat2 samtools subread   # 质控/预处理/比对/计数
# 可选：STAR、RSEM、salmon、sambamba
```

非 conda 方式（下载预编译包）见用户笔记 `background.md`（sratoolkit、FastQC、
fastp、hisat2、STAR、RSEM、salmon、featureCounts、samtools、sambamba 的 wget 地址）。

## 2. 数据下载

数据来源：NCBI SRA、EBI ENA、DDBJ、CNCB。**推荐从 EBI 直接下载 .fastq.gz**。

### 方法 A：prefetch（sra-toolkit）

```bash
cat SRR_Acc_List.txt | while read id; do (nohup prefetch ${id} &); done
# 或
nohup prefetch -O ./ --option-file srr_list.txt --max-size u 1>down.log 2>&
# .sra → fastq
for i in $analysis_dir/SRR*/*sra; do
  nohup fastq-dump --split-3 --gzip $i &
done
```

### 方法 B：wget 批量下载（推荐，支持断点续传 `-c`）

从 EBI 下载 `filereport_read_run_*.tsv.txt`，提取第 7 列生成下载链接：

```bash
# 单端（单文件/样本）
cat filereport_read_run_PRJNA302755_tsv.txt | cut -f 7 | sed -e 1d \
  | awk '{print "ftp://"$0}' > address.txt
# 双端（两文件用 ; 分隔，需拆行）
cat filereport_read_run_PRJNA450208_tsv.txt | cut -f 7 | sed -e 1d \
  | sed -r 's/;/\n/' | awk '{print "ftp://"$0}' > address.txt

cat address.txt | while read id; do nohup wget -c $id & done
```

- `sed -r 's/;/\n/'` 用于双端测序：同一行两个 `_1.fastq.gz` 与 `_2.fastq.gz` 以 `;` 分隔。
- 也可按规律直接拼 ftp 路径：`ftp://ftp.sra.ebi.ac.uk/vol1/fastq/<SRRxxx>/<SRRxxx>.fastq.gz`。
- 备选：`axel -n 10` 多线程；Aspera `ascp`（时灵时不灵）。
- **下载后务必检查数据完整性**（文件大小、`gzip -t`、md5）。

## 3. 质控与预处理

```bash
# 质控评估
fastqc ./*.fastq -o ./          # 或 ./*.fastq.gz
# 预处理（去接头、去低质量碱基）
fastp -i raw_R1.fastq -I raw_R2.fastq \
      -o cleaned_R1.fastq -O cleaned_R2.fastq \
      -h fastp_report.html
# 单端：只用 -i/-o
```

- FastQC 检查：读长/质量分布、GC 含量、过度重复、接头含量。
- fastp 参数按需调整，默认即可；也可用 TrimGalore 或 Trimmomatic。

## 4. 比对到参考基因组

先下载参考基因组索引。当前常用 hg38（人）/ mm10（鼠）。

```bash
# hisat2 索引（人 GRCh38）
wget https://genome-idx.s3.amazonaws.com/hisat/grch38_genome.tar.gz
tar -zxvf grch38_genome.tar.gz

# 比对（双端）
hisat2 -p 8 -x ./grch38/genome \
       -1 ./cleaned_R1.fastq -2 ./cleaned_R2.fastq \
       -S ./cleaned_data.sam
```

- `-p` 线程数；`-x` 索引前缀（到 genome 为止）；`-1/-2` 双端输入；`-U` 单端；`-S` 输出 SAM。
- 备选比对器：STAR（更快，适合大量数据，需 `--genomeDir` 构建索引）。

## 5. 排序与转 BAM

```bash
samtools view -bS cleaned_data.sam | samtools sort -o cleaned_data_sorted.bam
samtools index cleaned_data_sorted.bam   # 数据量大时建索引
```

- `-b` 输出 BAM；`-S` 输入为 SAM。可加 `-@ N` 多线程。
- 数据小可不建索引；数据大建议建索引加速后续。

## 6. 定量（count 矩阵）

### featureCounts（subread，推荐，从 BAM）

先下载物种对应 GTF 注释（人：gencode.v44；鼠：gencode.vM25）：

```bash
featureCounts -p -B -C -T 8 \
  -a ./gencode.v44.annotation.gtf.gz \
  -o data_counts.txt cleaned_data_sorted.bam
```

- `-p` 仅用于 paired-end，统计 fragment 而非 read。
- `-B` 仅统计两端都比对上的 fragment（需 `-p`）。
- `-C` 排除比对到不同染色体的融合 fragment（需 `-p`）。
- `-T` 线程数（1~32）；`-a` 注释 GTF（支持 .gz）。
- 输出共 7 列：基因 id、染色体、起始、终止、链、长度、count 值。

### 备选定量器

- **salmon**：免比对直接定量转录本，输出 TPM，下游走 tximport。
- **RSEM**：比对后定量，输出 expected_count / TPM / FPKM。
- 二者可直接拿 TPM，跳过手工定量转换；但 count 建议仍走 tximport 导入 DESeq2。

## 参考基因组与注释口径

- 人：GRCh38/hg38，GENCODE v44（`gencode.v44.annotation.gtf.gz`）。
- 鼠：GRCm38/mm10，GENCODE vM25（`gencode.vM25.annotation.gtf.gz`）。
- 参考基因组版本**必须与后续定量转换所用的基因长度来源一致**（见
  `downstream-prep.md`），否则 TPM/FPKM 会算错。
