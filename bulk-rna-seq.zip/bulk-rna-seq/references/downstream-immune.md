# 下游分析（R）：免疫浸润、分子分型、EMT 评分与基因功能注释

本模块覆盖 bulk RNA-seq 拿到表达矩阵后的一组扩展分析，内容提炼自「被炸熟的虾」公众号
免疫浸润与分子分型系列贴文。

## 1. 免疫浸润与肿瘤微环境

### 1.1 CIBERSORT（22 种免疫细胞去卷积）

基于 LM22 特征矩阵（547 个特征基因 × 22 种免疫细胞）的线性去卷积，估计各细胞
相对丰度（22 种细胞占比之和为 1）。

```r
# install.packages("devtools"); devtools::install_github("Moonerss/CIBERSORT")
library(CIBERSORT)
data(LM22)          # 547 × 22 免疫细胞特征基因
data(mixed_expr)    # 示例表达矩阵（基因 × 样本）
results <- cibersort(sig_matrix = LM22, mixture_file = mixed_expr,
                     perm = 1000, QN = FALSE)
```

- `perm`：置换检验次数，≥100 才计算 p 值。
- `QN`：是否对输入做分位数标准化，芯片多设 TRUE，测序多设 FALSE。
- **输入数据要求（务必遵守）**：非负、无缺失、非 log 线性空间；RNA-seq 用
  TPM/FPKM（**不要取 log**）；若矩阵已取 log 需先 anti-log。
- 结果多出三列：P-value、Correlation、RMSE。

组间差异可视化（如基因高低表达分组）：

```r
re <- as.data.frame(results[, -(23:25)])     # 去掉 P-value/Correlation/RMSE 三列
re$SampleNames <- rownames(re)
dat <- reshape2::melt(re, id = "SampleNames")
colnames(dat)[2:3] <- c("Cell_type", "Proportion")
dat$Group <- rep(exprSet$Group, 22)          # 每个样本的分组

library(ggplot2); library(ggpubr)
p <- ggplot(dat, aes(x = Cell_type, y = Proportion, fill = factor(Group))) +
  geom_violin(position = position_dodge(width = 1), scale = "width") +
  geom_boxplot(position = position_dodge(width = 1), outlier.shape = NA,
               width = 0.25, alpha = 0.2, show.legend = FALSE) +
  scale_fill_manual(values = alpha(RColorBrewer::brewer.pal(8, "Set1")[1:2], 0.6)) +
  theme_bw() + labs(y = "Immune Cell Relative Proportion", fill = NULL)
# 用 ggpubr::compare_means + geom_signif 添加 wilcox 显著性（ns 项置 NA）
```

### 1.2 ESTIMATE（基质/免疫评分 + 肿瘤纯度）

基于 ssGSEA 的 StromalSignature / ImmuneSignature 基因集，得到基质评分、免疫评分
与 ESTIMATE 评分（两者之和），并推算肿瘤纯度。

```r
# install.packages("estimate", repos = "http://r-forge.r-project.org",
#                  dependencies = TRUE)
library(estimate)
estimate <- function(dat, pro) {
  input.f <- paste0(pro, "_estimate_input.txt")
  output.f <- paste0(pro, "_estimate_gene.gct")
  output.ds <- paste0(pro, "_estimate_score.gct")
  write.table(dat, file = input.f, sep = "\t", quote = FALSE)
  filterCommonGenes(input.f = input.f, output.f = output.f, id = "GeneSymbol")
  estimateScore(input.ds = output.f, output.ds = output.ds, platform = "illumina")
  scores <- read.table(output.ds, skip = 2, header = TRUE)
  rownames(scores) <- scores[, 1]
  scores <- t(scores[, 3:ncol(scores)])
  scores
}
```

- **转录组数据 `platform` 必须设为 `"illumina"`**（默认 affymetrix 用于芯片）。
- 输入用 log 后数据：logCPM、logTPM 或 logFPKM 均可（原文用 RNAseqV2 RSEM）。
- 常见做法：`log2(edgeR::cpm(count) + 1)` 作为输入。
- 转录组输出**没有 TumorPurity 列**，需按 13 年公式手动计算：

```r
TumorPurity <- cos(0.6049872018 + 0.0001467884 * scores[, 3])   # 第3列 ESTIMATEScore
```

- 注意：肿瘤纯度公式来自芯片数据，转录组数据建议只用 estimate score 作为相对
  度量，而非绝对纯度。官网（MD Anderson）也提供 TCGA 样本的预计算 ESTIMATE 结果。

### 1.3 ssGSEA（单样本免疫浸润）

见 `downstream-enrich.md` 的 GSVA/ssGSEA 部分。此处用免疫细胞 marker 基因集
（如 28 种免疫细胞、29 个免疫特征基因集）跑 `GSVA::gsva(..., method = "ssgsea")`。
热图若需行名在左侧，用 modified_pheatmap 脚本（见原笔记）。

### 1.4 xCell（64 种细胞类型）

```r
# devtools::install_github("dviraran/xCell")
library(xCell)
# 表达矩阵：基因(SYMBOL) × 样本；芯片与 RNA-seq 均可，内部自动处理
result <- xCellAnalysis(expr)     # 返回细胞类型 × 样本的富集得分
```

### 1.5 MCP-counter（8 免疫 + 2 基质细胞群体）

```r
# devtools::install_github("ebecht/MCPcounter", ref = "master", subdir = "Source")
library(MCPcounter)
result <- MCPcounter.estimate(expression, featuresType = "HUGO_symbols",
                              probesets = read.table(curl("...probesets.txt"),
                                                     sep = "\t", stringsAsFactors = FALSE))
```

### 1.6 TIMER / TIMER2.0（在线工具）

TIMER（http://timer.cistrome.org/）与 TIMER2.0 提供 6 种免疫细胞浸润的预计算
结果（CIBERSORT、CIBERSORT-ABS、EPIC、MCPCOUNTER、QUANTISEQ、TIMER、XCELL 等
多算法），可直接下载 TCGA 样本的浸润分数，无需本地计算。

### 1.7 TMEscore

```r
# devtools::install_github("DongqiangZeng0808/TMEscore")
library(TMEscore)
# 返回 TMEscoreA/TMEscoreB/TMEscore 及二分分类 TMEscore_binary，可接生存分析
```

### 1.8 IOBR（一站式免疫浸润集成）

```r
# devtools::install_github("IOBR/IOBR")
library(IOBR)
# deconvo_tme() 一键调用多种算法：
# "mcpcounter" "epic" "xcell" "cibersort" "cibersort_abs" "ips"
# "estimate" "svr" "lsei" "timer" "quantiseq"
res <- deconvo_tme(eset = expr, method = "cibersort", arrays = FALSE)
```

- IOBR 集成多种去卷积算法，统一返回长表（ID + 各细胞类型列），适合批量比较。

## 2. 乳腺癌 PAM50 分子分型（genefu）

PAM50 将乳腺癌分为 Luminal A / Luminal B / HER2-enriched / Basal-like / Normal-like
五类。R 用 `genefu` 包的 `molecular.subtyping`。

```r
BiocManager::install("genefu")
library(genefu)
data(pam50.robust)          # 必要加载，否则报"找不到对象 pam50.robust"
PAM50Preds <- molecular.subtyping(sbt.model = "pam50",
                                  data = t(exprSet),   # 样本 × 探针/基因
                                  annot = ids,         # 需含 "EntrezGene.ID" 列
                                  do.mapping = TRUE)
```

关键参数与注意：

- `sbt.model`：除 pam50 外还支持 scmgene、scmod1、scmod2、ssp2006、ssp2003、
  intClust、AIMS、claudinLow 等。
- `annot` 注释矩阵**至少需要一列名为 `EntrezGene.ID`**（intClust 模型用
  `Gene.Symbol`）。
- `do.mapping`：是否经 Entrez Gene ID 映射（有歧义时保留变异最大的探针）。
- 返回列表：`subtype`（亚型因子）、`subtype.proba`（属于各亚型概率）、
  `subtype.crisp`（明确亚型类别）。
- RNA-seq 数据：先 `log2(exp_TPM + 1)`，把 SYMBOL 经 `bitr` 转 ENTREZID 后构造
  annot；虽然 ID 转换率可能低（如 24.66% 未映射），但 PAM50 所需基因通常在，
  不影响继续。
- 经验：很多 LumA 会被判成 LumB，热图也显示类别边界模糊，解释时需谨慎。

结果校验与可视化：与作者/TCGA 自带分型做交叉表
`table(PAM50Preds$subtype, pd$PAM50)`；取 `pam50.robust$centroids` 的 50 个基因
画 pheatmap 热图（分组注释色：Basal #93cc82、Her2 #4d97cd、LumB #f6f5ee、
LumA #ea9c9d、Normal #e8c559）。

## 3. EMT 评分（上皮-间质转化）

### 3.1 imogimap::get_emt_score（77 基因加权）

```r
# remotes::install_github("korkutlab/imogimap")
library(imogimap)
EMTScore <- get_emt_score(pdf = exp_TPM)   # 样本为列、基因/蛋白为行
# 返回 Tumor_Sample_ID + EMTscore（已均值中心化与标准化）
```

### 3.2 手动计算（mesenchymal 减 epithelial）

经典做法：取高表达 EMT 基因，计算 mesenchymal 基因得分减 epithelial 基因得分。
两种口径：

1. **Lung Cancer 2020（6+6 基因 Z-score 法）**：6 个间质基因（AGER、FN1、MMP2、
   SNAI2、VIM、ZEB2）的 log2 Z-score 之和，减去 6 个上皮基因（CDH1、CDH3、CLDN4、
   EPCAM、MAL2、ST14）的 log2 Z-score 之和。
2. **Nature 2017（均值差法）**：mesenchymal 基因平均表达 − epithelial 基因平均表达。

```r
# 用 PMID:26420858 的 EMT 基因列表（EMTome 数据库）
Genelist <- read.csv("./PMID 26420858-EMT.csv")
MGene <- Genelist[Genelist$Group == "Mesenchymal", "Gene"]
EGene <- Genelist[Genelist$Group == "Epithelial", "Gene"]
# 取表达量最高的前 10 个
MGene <- MGene[order(sapply(MGene, function(x) sum(exp_TPM[x, ])), decreasing = TRUE)][1:10]
EGene <- EGene[order(sapply(EGene, function(x) sum(exp_TPM[x, ])), decreasing = TRUE)][1:10]
exprSet <- t(scale(t(log2(exp_TPM + 0.01))))
OwnScore <- apply(exprSet[MGene, ], 2, sum) - apply(exprSet[EGene, ], 2, sum)
```

- EMT 基因来源：EMTome 数据库（http://www.emtome.org/），含 Signature/Genes/
  Interactome/Score/CRISPR 五模块。
- 用 `cor.test(..., method = "spearman")` 比对不同方法/原文结果的相似性。

## 4. 基因功能通路批量注释（MSigDB）

批量查询单个/一组基因所属的功能通路，主要用 `msigdbr` 包 + clusterProfiler。

```r
library(msigdbr)
# 查看可用物种与基因集
msigdbr_show_species()
msigdbr_collections()
# 下载某物种某集合：默认用 KEGG（与 ORA/GSEA 口径一致）
m_df <- msigdbr(species = "Homo sapiens", category = "C2", subcategory = "CP:KEGG")
# 查询特定基因所属通路
m_df[m_df$gene_symbol == "CD244", c("gs_name", "gene_symbol")]
```

- **集合选择（硬性）**：批量注释默认用 KEGG（或 GO，`category = "C5"`）；
  Hallmark（`category = "H"`）、Reactome 仅在用户明确点名时使用，
  代码示例中也不作为默认写法。

- MSigDB 集合：C1 位置、C2 化学/遗传扰动（CGP/CP 含 KEGG/REACTOME/BIOCARTA/PID/
  WikiPathways）、C3 调控靶点（MIR）、C4 计算、C5 本体、C6 致癌、C7 免疫、C8 细胞类型、
  H hallmark。
- 也可用 clusterProfiler 的 `enricher(TERM2GENE = ...)` 对自定义基因集做富集。
- 在线工具：GSEA/MSigDB 官网按基因查所属基因集。

## 5. 可视化规范

- 图内英文，`theme_bw`，配色 `#0074b3`（蓝）/ `#982b2b`（红）；图例实心方块。
- 免疫浸润箱线/小提琴图用 `ggpubr::compare_means` + `geom_signif`，ns 项标 NA。
- 字号宁大勿小；分型热图用 pheatmap，行名在左需 modified_pheatmap。
