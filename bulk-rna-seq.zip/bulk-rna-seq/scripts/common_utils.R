# bulk-rna-seq 核心可复用函数
# 用法：source("common_utils.R") 后直接调用
# 依赖：rtracklayer, ggplot2, pheatmap, FactoMineR, factoextra；psych 可选（缺省用基 R 实现）

## 投稿风格 ggplot2 主题
mytheme <- function() {
  require(ggplot2)
  theme_bw() +
    theme(legend.key = element_rect(fill = "transparent"),
          legend.background = element_rect(fill = "transparent"),
          legend.position = "top",
          legend.title = element_blank(),
          legend.text = element_text(size = 20, margin = margin(t = 6)),
          axis.text.x = element_text(hjust = 0.5, size = 18),
          axis.text.y = element_text(size = 18),
          axis.title.x = element_text(size = 20),
          axis.title.y = element_text(size = 20),
          axis.line = element_line(size = 1),
          plot.title = element_text(size = 24, hjust = 0.5))
}

## 从 GTF 提取非冗余外显子长度
gtf_gene_length <- function(gtf_path) {
  require(rtracklayer)
  gtf <- as.data.frame(rtracklayer::import(gtf_path))
  exon <- gtf[gtf$type == "exon", c("start", "end", "gene_id")]
  gle <- lapply(split(exon, exon$gene_id), function(x) {
    tmp <- apply(x, 1, function(y) y[1]:y[2])
    length(unique(as.integer(unlist(tmp))))
  })
  data.frame(gene_id = names(gle), length = as.numeric(gle))
}

## Count → FPKM
CountToFPKM <- function(counts, effLen) {
  N <- sum(counts)
  exp(log(counts) + log(1e9) - log(effLen) - log(N))
}

## Count → TPM
CountToTPM <- function(counts, effLen) {
  rate <- log(counts) - log(effLen)
  denom <- log(sum(exp(rate)))
  exp(rate - denom + log(1e6))
}

## ENSEMBL → SYMBOL 转换 + 去重（取平均表达最高）
ensembl_to_symbol <- function(expr, gtf_path) {
  require(rtracklayer)
  gtf <- as.data.frame(rtracklayer::import(gtf_path))
  ids <- data.frame(ENSEMBL = gtf$gene_id[gtf$type == "gene"],
                    SYMBOL  = gtf$gene_name[gtf$type == "gene"])
  expr <- expr[ids$ENSEMBL, ]
  ids$max <- apply(expr, 1, mean)
  ids <- ids[order(ids$SYMBOL, ids$max, decreasing = TRUE), ]
  ids <- ids[!duplicated(ids$SYMBOL), ]
  dat <- expr[ids$ENSEMBL, ]
  rownames(dat) <- ids$SYMBOL
  dat
}

## 过滤低表达基因
filter_low_expr <- function(count_mat, min_mean = 1, min_frac = 0.8) {
  keep <- rowMeans(count_mat) > min_mean &
          rowSums(count_mat > 0) >= min_frac * ncol(count_mat)
  count_mat[keep, ]
}

## PCA 散点图
draw_pca <- function(expr, Group, title = "PCA", palette = c("#982b2b", "#0074b3")) {
  require(FactoMineR); require(factoextra)
  set.seed(1234)
  pca <- prcomp(t(log2(expr + 1)), scale = TRUE, center = TRUE)
  fviz_pca_ind(pca, geom.ind = "point", pointsize = 6, col.ind = Group,
               addEllipses = TRUE, mean.point = FALSE, palette = palette) +
    ggtitle(title) + mytheme()
}

## Spearman 相关矩阵 + p 值（基 R 实现，不依赖 psych）
## 与 psych::corr.test(method = "spearman") 的 p 值算法一致（t 近似）
cor_spearman <- function(mat) {
  r <- cor(mat, method = "spearman")
  n <- ncol(mat)
  if (n < 3) {
    p <- matrix(1, nrow(r), ncol(r), dimnames = dimnames(r))
  } else {
    tstat <- r * sqrt((n - 2) / (1 - r^2))
    p <- 2 * pt(-abs(tstat), df = n - 2)
  }
  p[!is.finite(p)] <- 1        # 完全相关或常数列
  diag(p) <- 0
  list(r = r, p = p)
}

## 组间相关性热图（单版；top_n = NULL 表示用全部基因）
draw_corr_heatmap <- function(expr, top_n = NULL, title = NULL) {
  require(pheatmap)
  expr_log <- log2(expr + 1)                       # MAD 与相关系数均在此尺度上算
  if (!is.null(top_n)) {
    gl <- names(head(sort(apply(expr_log, 1, mad), decreasing = TRUE), top_n))
    expr_log <- expr_log[gl, ]
  }
  corr <- if (requireNamespace("psych", quietly = TRUE)) {
    psych::corr.test(x = expr_log, method = "spearman")   # 装了 psych 则用其实现
  } else {
    cor_spearman(expr_log)
  }
  pheatmap(corr$r, scale = "none",
           fontsize_number = 12, fontsize_row = 18, fontsize_col = 18,
           cellwidth = 50, cellheight = 50,
           cluster_rows = TRUE, cluster_cols = TRUE,
           display_numbers = signif(corr$p, 2),
           color = colorRampPalette(c("#0f86a9", "white", "#ed8b10"))(100),
           main = title)
}

## 分析前评估默认规则：相关性热图一次出两版（全部基因 + MAD top 2000）
draw_corr_heatmap_pair <- function(expr, top_n = 2000L) {
  p_all <- draw_corr_heatmap(expr, top_n = NULL,
                             title = "Correlation heatmap (all genes)")
  p_top <- draw_corr_heatmap(expr, top_n = top_n,
                             title = sprintf("Correlation heatmap (top %d MAD genes)", top_n))
  invisible(list(all_genes = p_all, top_mad = p_top))
}

## 样本层次聚类（树状图 + 聚类热图；默认与相关性热图同口径：MAD top 2000）
draw_hclust <- function(expr, Group = NULL, top_n = 2000L,
                        palette = c("#0074b3", "#982b2b"),
                        title = "Hierarchical Clustering") {
  require(pheatmap); require(factoextra)
  expr_log <- log2(expr + 1)
  gl <- names(head(sort(apply(expr_log, 1, mad), decreasing = TRUE), top_n))
  mat <- expr_log[gl, ]

  hc <- hclust(dist(t(mat), method = "euclidean"), method = "complete")
  k <- if (is.null(Group)) 2L else length(unique(Group))
  k <- max(2L, min(k, ncol(mat) - 1L))
  dend <- fviz_dend(hc, k = k, main = title, cex = 1, horiz = TRUE,
                    color_labels_by_k = TRUE, rect = TRUE,
                    palette = rev(palette)) +
    theme_void() + theme(plot.title = element_text(size = 24, hjust = 0.5))

  ann_col <- NULL; ann_colors <- NULL
  if (!is.null(Group)) {
    g <- factor(Group)
    ann_col <- data.frame(Group = g)
    rownames(ann_col) <- colnames(mat)
    ann_colors <- list(Group = setNames(rep(palette, length.out = nlevels(g)),
                                        levels(g)))
  }

  hm <- pheatmap(mat, scale = "row",
                 annotation_col = ann_col, annotation_colors = ann_colors,
                 fontsize_col = 12, angle_col = 0,
                 cluster_rows = TRUE, cluster_cols = TRUE,
                 color = colorRampPalette(c("#0f86a9", "white", "#ed8b10"))(100),
                 show_rownames = FALSE, silent = TRUE)
  invisible(list(dendrogram = dend, heatmap = hm$gtable))
}
